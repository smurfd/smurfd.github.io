/*
 * ZStars.hpp - 1998/04/06
 *
 * Copyright (C) 1998 Johan Sorlin, spocke@algonet.se
 *
 * No Updates
 *
 */

#ifndef ZSTARS_HPP
#define ZSTARS_HPP

/* * * * Class Definition * * * */

class ZStars {
public:
	/* Constructor & DeConstructor */
	ZStars( );
	~ZStars( );

	/* Making/Disposing Methods */
	void makeStars( RECT in_rect, short num_stars, short warp, short max_speed );
	void dispose( );

	/* Drawing Methods */
	void drawStars( short ang );

private:
	/* Private Methods */
	void moveBackStar( short star_num );
	short rnd( short min, short max );

	/* ZStars Main Data */
	short	*Stars_X;
	short	*Stars_Y;
	short	*Stars_Z;
	short	*Stars_Speed;
	short	*Stars_OldX;
	short	*Stars_OldY;

	RECT	MainRect;
	short	NumberOfStars;
	short	WarpFactor;
	short	MaxSpeed;

	short	MiddleX;
	short	MiddleY;
};

#endif
