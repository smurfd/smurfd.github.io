// * * Globals

#define FULL_SCREEN		0x00000001
#define EXACT_MODE		0x00000002
#define ASK_POLITE		0x00000004
#define VBL_SYNC		0x00000008
#define DOUBLE_BUFFER	0x00000016


class GameClass {
public:
	GameClass( );
	~GameClass( );

	void startMainLoop( );	// Call this to start the shit

	void init( );
	void start( );
	int  stop( );

	void update( );		// gets called 30fps

	void mouseDown( struct Event evt, int x, int y );
	void mouseUp( struct Event evt, int x, int y );
	void mouseMove( struct Event evt, int x, int y );
	void mouseDrag( struct Event evt, int x, int y );

	void keyDown( struct Event evt, int key );
	void keyUp( struct Event evt, int key );

	void lockPage( char **base, long *bytes_per_row );
	void unlockPage( );

	void setVBLSync( Boolean toggle );
	void setDBuffer( Boolean toggle );
	void setDirtyRect( int x1, int y1, int x2, int y2 );

	void switchDepth( int depth );
	void switchMode( int width, int height, int detph ); // If 0 then NO_CHANGE

	void setRGBAtIndex( BYTE red, BYTE green, BYTE blue, BYTE index );
	void getRGBAtIndex( BYTE *red, BYTE *green, BYTE *blue, BYTE index );

private:
	void systemtask( );		// 
}

int main( ) {
	GameClass	menu( );
	GameClass	game( );
	Boolean		exitBool;

	Init( );
	
	openScreen( 640, 480, 8, FULL_SCREEN );

	exitBool = menu.startMainLoop( );

	while( exitBool != TRUE ) {
		game.startMainLoop( );
		exitBool = menu.startMainLoop( );
	}

	closeScreen( );

	return 0;
}