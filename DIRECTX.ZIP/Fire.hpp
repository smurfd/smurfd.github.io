/*
 * Sprite.hpp - v1.0 - 1998/03/04
 *
 * Copyright (C) Johan Sorlin, spocke@algonet.se
 *
 *
 * 1.0 - 1998/03/04 - This file was created
 *
 */

#ifndef SPRITE_HPP
#define SPRITE-HPP

class Sprite {
public:
	/* Constructor & DeConstructor */
	Sprite( );
	~Sprite( );

	/* Accessor Methods */
	short getLocationX( );
	short getLocationY( );
	short getZLevel( );

	/* Mutator Methods */
	void setLocation( short x, short y );
	void setZLevel( short z_level );
	
	/* Drawing/Blitting Methods */
	int update( );

private:
	short	Cur_X;
	short	Cur_Y;
	short	Old_X;
	short	Old_Y;
};

#endif
