/*
 * Lens.cpp - v1.0 - 1998/03/12
 *
 * Copyright (C) Johan Sorlin, spocke@algonet.se
 *
 *
 * 1.0 - 1998/03/12 - This file was created
 *
 */

/* ANSI Includes */
#include <Math.h>
#include <stdlib.h>

/* Local Includes */
#include "GameShell.hpp"


/* * * * Class Definition * * * */

class Lens {
public:
	/* Constructor & DeConstrustor */
	Lens( );
	~Lens( );
	
	/* Make and Dispose */
	void make( short diameter, short mfactor );
	void dispose( );
	
	/* Drawing Mehtods */
	void draw( short off_x, short off_y );

private:
	char	*oData;
	short	*tfm;
	short	diameter;
	
	short	old_posX;
	short	old_posY;
};

// GlassLens.make( 64, 10, 2 );


/* * * * Constructor & DeConstrustor * * * */

Lens::Lens( )
{
	this->oData		=	NULL;
	this->tfm		=	NULL;
	
	this->old_posX	=	-1;
	this->old_posY	=	-1;
	this->diameter	=	0;
}

Lens::~Lens( )
{
	this->dispose( );
}


/* * * * Make and Dispose * * * */

void Lens::make( short diameter, short mfactor )
{
	short		r,y,x,a,b;
	float		s,z;

	/* DeAllocate old mem */
	this->dispose( );

	/* Allocate space for oldData */
	this->oData = (char *) malloc( sizeof( char ) * (long) (diameter * diameter) );
	if( this->oData == NULL )
	{
		/* Error */
		return;
	}

	/* Allocate space for tfm */
	this->tfm = (short *) malloc( sizeof( char ) * (long) (diameter * diameter) );
	if( this->tfm == NULL )
	{
		/* Error */
		return;
	}

	this->diameter	=	diameter - 2;
	this->old_posX	=	-1;
	this->old_posY	=	-1;

	/* Create Lens */
	r = this->diameter / 2;
	s = sqrt( (float) r * r - mfactor * mfactor );

	for( y = -r; y<r; y++ )
	for( x = -r; x<r; x++ )
	{
		if( x*x + y*y >= s*s )
		{
			a = x;
			b = y;
		}
		else
		{
			z = sqrt( (float) r*r - x*x - y*y );
			a = ( x * mfactor / (float) z + 0.5 );
			b = ( y * mfactor / (float) z + 0.5 );
		}

		tfm[ (y + r) * this->diameter + (x + r) ] = (b + r) * this->diameter + (a + r);
	}
	
//	for( short i=0; i<this->diameter*this->diameter; i++ )
//		tfm[ this->diameter*this->diameter-i ] = i;
}

void Lens::dispose( )
{
	if( this->oData != NULL )
	{
		free( (void *) this->oData );
		this->oData = NULL;
	}

	if( this->tfm != NULL )
	{
		free( (void *) this->tfm );
		this->tfm = NULL;
	}
}


/* * * * Drawing Mehtods * * * */

void Lens::draw( short off_x, short off_y )
{
	short x,y,count;
//	Rect r;

	if( off_x < 0 ) off_x = 0;
	if( off_y < 0 ) off_y = 0;
	if( off_x > 639-this->diameter ) off_x = 639-this->diameter;
	if( off_y > 479-this->diameter ) off_y = 479-this->diameter;

	game.lockPage( BackPage );

	/* Put Org */
	if( this->old_posX != -1 )
	{
		count = 0;
		for( y=0; y<this->diameter; y++ )
		for( x=0; x<this->diameter; x++ )
			game.putPixel8( x + this->old_posX, y + this->old_posY, this->oData[ count++ ] );
	}

	/* Save old pos */
	this->old_posX = off_x;
	this->old_posY = off_y;

	/* Get Old */
	count = 0;
	for( y=0; y<this->diameter; y++ )
	for( x=0; x<this->diameter; x++ )
		this->oData[ count++ ] = game.getPixel8( x + off_x, y + off_y );

	/* Put lens */
	count = 0;
	for( y=0; y<this->diameter; y++ )
	for( x=0; x<this->diameter; x++ )
		game.putPixel8( x+off_x, y+off_y, this->oData[ tfm[ count++ ] ] );

	game.unlockPage( BackPage );

	game.flipPages( );
//	SetRect( &r, off_x, off_y, off_x+128, off_y+128 );
//	game.copyArea( BackPage, &r, FrontPage, off_x, off_y );
}
