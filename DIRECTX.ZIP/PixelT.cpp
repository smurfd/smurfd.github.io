/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
**
**	File Name:	PixelTunnel.c
**	Version:	v1.0 <BETA>
**	Created by:	Johan S�rlin
**	Email:		Johan.Sorlin@mailbox.hogia.net
**	Last update:	97-04-04 16.32.09
**
** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <math.h>
#include "GameApp.hpp"

#ifdef fdsfdsfds
////////////////////////////// INCLUDES //////////////////////////////

#include <My_Include.h>
#include <FastGFX.h>

#include <math.h>

#include <mouse.h>

///////////////////////////// CONSTANTS /////////////////////////////

#define NR_DOTS			36
#define NR_CIRS			60
#define DIAMETER		80

// * * MAXX,MAXY is defines in FastGFX.h
#define MAXZ			255

#define X_OFF			320
#define Y_OFF			240
#define Z_OFF			255

///////////////////////////// GLOBAL VARS /////////////////////////////

struct TunnelForm {
	short	x[ NR_DOTS+1 ];
	short	y[ NR_DOTS+1 ];

	short	ox[ NR_DOTS+1 ];
	short	oy[ NR_DOTS+1 ];
	
	short	off_x;
	short	off_y;
	short	off_z;
};

struct TunnelForm	*Tunnel = 0L;

///////////////////////////// FUNCTIONS /////////////////////////////

void InitTunnel( void )
{
	short	i,a;
	double	sintab[ NR_DOTS + 1 ],costab[ NR_DOTS + 1 ];

	Tunnel = (struct TunnelForm *) NewPtr( sizeof( struct TunnelForm ) * (NR_CIRS+1) );
	if( Tunnel == 0L )	ExitToShell( );
	
	for( i=0;i<=NR_DOTS;i++ )
	{
		sintab[ i ] = (double) sinq( i * (360/NR_DOTS) );
		costab[ i ] = (double) cosq( i * (360/NR_DOTS) );		
	}

	for( i=0;i<=NR_CIRS;i++ )
	{
		for( a=0;a<=NR_DOTS;a++ )
		{
			Tunnel[ i ].x[ a ] = (short) (sintab[ a ] * DIAMETER);
			Tunnel[ i ].y[ a ] = (short) (costab[ a ] * DIAMETER);

			Tunnel[ i ].ox[ a ] = 0;
			Tunnel[ i ].oy[ a ] = 0;
		}

		Tunnel[ i ].off_x  = 0;
		Tunnel[ i ].off_y  = 0;
		Tunnel[ i ].off_z  = (i*3) + 15;
	}
}

short co = 0;

void UpdateTunnel( void )
{
	short		i,a,nx,ny;

//	if( co >= 360-3 ) co = 0;
//	else co+=3;

//	Tunnel[ NR_CIRS-1 ].off_x = sinq( co ) * 50;//MOUSEX - 320;
//	Tunnel[ NR_CIRS-1 ].off_y = cosq( co ) * 30;//MOUSEY - 200;

	Tunnel[ NR_CIRS-1 ].off_x = MouseX - MEDX;
	Tunnel[ NR_CIRS-1 ].off_y = MouseY - MEDY;

	for( i=0;i<=NR_CIRS-2;i++ )
	{
		Tunnel[ i ].off_x = Tunnel[ i+1 ].off_x;
		Tunnel[ i ].off_y = Tunnel[ i+1 ].off_y;
	}

	for( i=0;i<=NR_CIRS-1;i++ )
	{
		for( a=0;a<=NR_DOTS-1;a++ )
		{
			nx = ( ( (Tunnel[ i ].x[ a ] ) << 7 ) / (Tunnel[ i ].off_z) ) + (X_OFF+Tunnel[ i ].off_x);
			ny = ( ( (Tunnel[ i ].y[ a ] ) << 7 ) / (Tunnel[ i ].off_z) ) + (Y_OFF+Tunnel[ i ].off_y);

			FPutPixel( Tunnel[ i ].ox[ a ],Tunnel[ i ].oy[ a ],255,MainScreen );

			if( nx > 0 && nx <= MAXX && ny > 0 && ny <= MAXY )
			{
				FPutPixel( nx,ny,(byte) Tunnel[ i ].off_z,MainScreen );

				Tunnel[ i ].ox[ a ] = nx;
				Tunnel[ i ].oy[ a ] = ny;
			}
		}
	}

}

void CloseTunnel( void )
{
	if( Tunnel != 0L )
	{
		DisposePtr( (Ptr) Tunnel );
		Tunnel = 0L;
	}
}

///////////////////////////// MAIN CODE /////////////////////////////

extern void VBLCounterTask( void );
extern OSErr InstallVBL( void );
extern OSErr RemoveVBL( void );
extern long GetVBLValue( void );
extern void SetVBLValue( long value );
extern void WaitVBL( void );
extern void mainfffcc( void );

void mainhgghhgjghj( void )
{
	Init( );
	InitFGFX( RESL_640x480x256,0 );
	FGFX_ErrorMsg( );

	HideMouse( );
	MoveMouse( 320,240-(DIAMETER/2) );
	InitMouse( );

	InitTunnel( );

//	InstallVBL( );

	SetColors( "Gray2" );

	repeat
		GetMouseInfo( );
		// WaitVBL( );
		UpdateTunnel( );
	until( LButton || RButton );

//	RemoveVBL( );

	CloseFGFX( );
	CloseTunnel( );
}
#endif

class PTunnel {
public:
	/* Constructor & DeConstucutor */
	PTunnel( );
	~PTunnel( );

	/* */
	void make( RECT in_rect, short num_rings, short diameter );
	void draw( short pos_x, short pos_y );
	void dispose( );

private:
	RECT	MainRect;
	short	NumberOfRings;
	short	RingDiameter;

	struct Ring {
		short Pixel_X[36];
		short Pixel_Y[36];

		short Pos_X;
		short Pos_Y;
		short OldPos_X;
		short OldPos_Y;
	} *Rings;
};

PTunnel::PTunnel( )
{
	SetRect( &this->MainRect, 0, 0, 0, 0 );
	this->NumberOfRings = 0;
	this->RingDiameter  = 0;
	this->Rings = NULL;
}

PTunnel::~PTunnel( )
{
}

#define sinq( ang ) sin( (ang) * 0.01745f ) 
#define cosq( ang ) cos( (ang) * 0.01745f )

void PTunnel::make( RECT in_rect, short num_rings, short diameter )
{
	int		a,i;
	short	x, y, z;

	/* If allocated, then DeAllocate */
	this->dispose( );

	this->Rings = (struct Ring *) malloc( (long) num_rings * sizeof( struct Ring ) );

	for( a=0; a<num_rings; a++ )
	for( i=0; i<36; i++ )
	{
		x	=	(short) ( sinq( i * (360/36) ) * (diameter /*- (a*(diameter/num_rings))*/ ) );
		y	=	(short) ( cosq( i * (360/36) ) * (diameter /*- (a*(diameter/num_rings))*/ ) );

//		x	=	(short) ( sinq( i * (360/36) ) * (diameter - (a*(diameter/num_rings)) ) );
//		y	=	(short) ( cosq( i * (360/36) ) * (diameter - (a*(diameter/num_rings)) ) );
		z	=	(a * 4) + 10;

		this->Rings[ a ].Pixel_X[ i ] = (short) ( ( x << 7 ) / z );
		this->Rings[ a ].Pixel_Y[ i ] = (short) ( ( y << 7 ) / z );

//		this->Rings[ a ].Pixel_X[ i ] = x;//(short) ( sinq( i * (360/36) ) * (diameter - (a*(diameter/num_rings)) ) );
//		this->Rings[ a ].Pixel_Y[ i ] = y;//(short) ( cosq( i * (360/36) ) * (diameter - (a*(diameter/num_rings))) );
		this->Rings[ a ].Pos_X = 320;
		this->Rings[ a ].Pos_Y = 240;
		this->Rings[ a ].OldPos_X = 320;
		this->Rings[ a ].OldPos_Y = 240;
	}

	SetRect( &this->MainRect, 0, 0, 639, 479 );
	this->NumberOfRings = num_rings;
	this->RingDiameter  = diameter;
}

void PTunnel::dispose( void )
{
}

void PTunnel::draw( short pos_x, short pos_y )
{
	int i,a,nx,ny;

	this->Rings[ this->NumberOfRings-1 ].Pos_X = pos_x;
	this->Rings[ this->NumberOfRings-1 ].Pos_Y = pos_y;

	for( i=0; i<this->NumberOfRings-1; i++ )
	{
		this->Rings[ i ].OldPos_X = this->Rings[ i ].Pos_X;
		this->Rings[ i ].OldPos_Y = this->Rings[ i ].Pos_Y;

		this->Rings[ i ].Pos_X = this->Rings[ i+1 ].Pos_X;
		this->Rings[ i ].Pos_Y = this->Rings[ i+1 ].Pos_Y;
	}

	game.lockPage( FrontPage );
	game.waitVBL( );
//	game.clearPage( FrontPage );

	for( i=0; i<this->NumberOfRings-1; i++ )
	{
		for( a=0; a<36; a++ )
		{
			nx = this->Rings[ i ].Pixel_X[ a ] + this->Rings[ i ].OldPos_X;
			ny = this->Rings[ i ].Pixel_Y[ a ] + this->Rings[ i ].OldPos_Y;

			if( nx < 639 && nx > 0 && ny < 479 && ny > 0 )
				game.putPixel8( nx, ny, 0 );

			nx = this->Rings[ i ].Pixel_X[ a ] + this->Rings[ i ].Pos_X;
			ny = this->Rings[ i ].Pixel_Y[ a ] + this->Rings[ i ].Pos_Y;

			if( nx < 639 && nx > 0 && ny < 479 && ny > 0 )
				game.putPixel8( nx, ny, 255 - (i * (255 / this->NumberOfRings)) );

//			this->Rings[ i ].Pixel_X[ a ] = (short) ((float) this->Rings[ i ].Pixel_X[ a ] * cos( 1 * 0.001745f ) - (float) this->Rings[ i ].Pixel_Y[ a ] * sin( 1 * 0.001745f ));
//			this->Rings[ i ].Pixel_Y[ a ] = (short) ((float) this->Rings[ i ].Pixel_X[ a ] * sin( 1 * 0.001745f ) + (float) this->Rings[ i ].Pixel_Y[ a ] * cos( 1 * 0.001745f ));
		}
	}

//	this->Rings[ 0 ].OldPos_X = this->Rings[ 0 ].Pos_X;
//	this->Rings[ 0 ].OldPos_Y = this->Rings[ 0 ].Pos_Y;

	game.unlockPage( FrontPage );
}