/*
 * GameApp.cpp - 1998/03/03
 *
 * Copyright (C) 1998 Johan Sorlin, spocke@algonet.se
 *
 * This file contains the GameApp class, this class
 * provides a game programmer with a simple API with
 * functions to open a screen, page flipping, palette.
 *
 * No Updates
 *
 */

/* Windows Specific Includes */
#include <ddraw.h>
#include <windows.h>
#include <windowsx.h>

/* Local Includes */
#include "DirectX.h"

/* * * * User defined extern Function Prototypes * * * * */
extern LRESULT CALLBACK WndProc( HWND, UINT, WPARAM, LPARAM );

const short FrontPage = 1;
const short BackPage  = 2;

class GameApp {
public:
	/* Constructor & DeConstrucor */
	GameApp( );
	~GameApp( );

	/* Screen Specific Methods */
	void openScreen( short width, short height, short depth, short flags );
	void closeScreen( );

	/* Accessor Methods */
	short getWidth( );
	short getHeight( );
	short getDepth( );
	short getFlags( );

	/* Page Methods */
	void setActivePage( short page );
	void FlipPages( );

	/* PutPixel Methods */
	void  putPixel8( short x, short y, char c );
	void  putPixel16( short x, short y, short c );
	void  putPixel32( short x, short y, long c );

	/* GetPixel Methods */
	char  getPixel8( short x, short y );
	short getPixel16( short x, short y );
	long  getPixel32( short x, short y );

	/* Palette Methods */
	void setRGBAtIndex( BYTE red, BYTE green, BYTE blue, BYTE index );
	void getRGBAtIndex( BYTE *red, BYTE *green, BYTE *blue, BYTE index );
	void updatePalette( );

	/* Game Specific Methods */
	void pause( void );
	void quit( void );
};






/* * * * GameApp Class Definition * * * */
class GameApp {
public:
	/* Constructor & DeConstrucor */
	GameApp( );
	~GameApp( );

	/* Screen Specific Methods */
	void openScreen( short width, short height, short depth, short flags );
	void closeScreen( void );

	/* Accessor Methods */
	short getWidth( void );
	short getHeight( void );
	short getDepth( void );
	short getFlags( void );
	char* getBasePtr( void );
	long  getBytesPerRow( void );

	/* Mutator Methods */
	void setUpdateRect( short x1, short y1, short x2, short y2 );

	/* Screen Draw Methods */
	void beginDraw( void );
	void endDraw( void );

	/* PixelBased Methods */
	void  putPixel8( short x, short y, char c );
	void  putPixel16( short x, short y, short c );
	void  putPixel32( short x, short y, long c );
	char  getPixel8( short x, short y );
	short getPixel16( short x, short y );
	long  getPixel32( short x, short y );

	/* Palette Methods */
	void setRGBAtIndex( short red, short green, short blue, short index );
	void getRGBAtIndex( short *red, short *green, short *blue, short index );
	void updatePalette( void );

	/* Game Specific Methods */
	void pause( void );
	void quit( void );

	/* Windows Specific Methods */
	void setHInstance( HINSTANCE hinstance );
	bool systemTask( void );

private:
	/* Current Page Data */
	char		*pageBase;
	long		pageBPR;
	short		pageWidth;
	short		pageHeight;
	short		pageDepth;
	char		**pageRows;

	/* Other GameApp Data */
	short		Flags;
	bool		Exit;
	RECT		updateRect;

	/* DirectDraw Data */
	LPDIRECTDRAW			IpDD;
	LPDIRECTDRAWSURFACE		IpDDSPrimary;
	LPDIRECTDRAWSURFACE		IpDDSBack;
	IDirectDrawPalette		*ddpal;
	PALETTEENTRY			ape[ 256 ];

	/* MainWindow Data */
	WNDCLASSEX				wndclass;
	MSG						msg;
	HWND					hwnd;
	char					szAppName[32];
	HINSTANCE				hInstance;
};


/* * * * Constructor & DeConstrucor * * * */

GameApp::GameApp( void )
{
	/* Initialize Current Page Data */
	this->pageBase		=	NULL;
	this->pageBPR		=	0L;
	this->pageWidth		=	0;
	this->pageHeight	=	0;
	this->pageDepth		=	0;
	this->pageRows		=	NULL;

	/* Initialize Other Game Data */
	this->Flags			=	0;
	this->Exit			=	false;
	SetRect( &this->updateRect, 0, 0, 0, 0 );

	/* Initialize DirectDraw Data */
	this->IpDD			=	NULL;
	this->IpDDSPrimary	=	NULL;
	this->IpDDSBack		=	NULL;
	this->ddpal			=	NULL;

	/* Initialize MainWindow Data */
	this->hwnd			=	NULL;
	strcpy( this->szAppName, "Game App Shell"  );
	this->hInstance		=	NULL;
}

GameApp::~GameApp( void )
{
	this->closeScreen( );
}


/* * * * Screen Specific Methods * * * */

void GameApp::openScreen( short width, short height, short depth, short flags )
{
	HRESULT			ddrval;
	DDSURFACEDESC	ddsd;
	DDSCAPS			ddscaps;

	/* Setup Window Class Data */
	wndclass.cbSize			= sizeof( wndclass );
	wndclass.style			= CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc	= WndProc;	/* Must exist a WndProc in Main source */
	wndclass.cbClsExtra		= 0;
	wndclass.cbWndExtra		= 0;
	wndclass.hInstance		= hInstance;
	wndclass.hIcon			= LoadIcon( NULL, IDI_APPLICATION );
	wndclass.hIconSm		= LoadIcon( NULL, IDI_APPLICATION );
	wndclass.hCursor		= LoadCursor( NULL, IDC_ARROW );
	wndclass.hbrBackground	= (HBRUSH) GetStockObject( WHITE_BRUSH );
	wndclass.lpszMenuName	= NULL;
	wndclass.lpszClassName	= szAppName;

	/* Register Window Class to system */
	if( !(RegisterClassEx( &wndclass )) )			
		return;

	/* Create the Main Window */
	hwnd = CreateWindowEx (
		WS_EX_APPWINDOW,				 // Extended Window Style
		szAppName,						 // Window Class Name
		"Game App Shell",				 // Window Caption
		WS_POPUP | WS_VISIBLE,			 // Window Style
		0,								 // Initial X Pos
		0,								 // Initial Y Pos
		GetSystemMetrics( SM_CXSCREEN ), // Initial X Size
		GetSystemMetrics( SM_CYSCREEN ), // Initial Y Size
		NULL,							 // Parent Window Handle
		NULL,							 // Window Menu Handle
		hInstance,						 // Program Instance Handle
		NULL);							 // Creation Paramaters

	/* Create DirectDraw Main Object */
	ddrval = DirectDrawCreate( NULL, &IpDD, NULL );
	if( ddrval != DD_OK )
	{
		/* Error */
		return;
	}

	/* Set to full screen */
	ddrval = IpDD->SetCooperativeLevel( hwnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN );
	if( ddrval != DD_OK )
	{
		/* Error */
		IpDD->Release( );
		return;
	}

	/* Switch resulution and depth */
	ddrval = IpDD->SetDisplayMode( width, height, depth );
	if( ddrval != DD_OK )
	{
		/* Error */
		IpDD->Release( );
		return;
	}

	/* Set and Creante main surface */
	memset( &ddsd, 0, sizeof( DDSURFACEDESC ) );
	ddsd.dwSize				= sizeof( DDSURFACEDESC );
	ddsd.dwFlags			= DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
	ddsd.ddsCaps.dwCaps		= DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX;
	ddsd.dwBackBufferCount	= 1;

	ddrval = IpDD->CreateSurface( &ddsd, &IpDDSPrimary, NULL );
	if( ddrval != DD_OK )
	{
		/* Error */
		IpDD->Release( );
		return;
	}

	/* Get Attached back buffer for page flipping */
	ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
	ddrval = IpDDSPrimary->GetAttachedSurface( &ddscaps, &IpDDSBack );
	if( ddrval != DD_OK )
	{
		/* Error */
		IpDDSPrimary->Release( );
		IpDD->Release( );
		return;
	}

	/* No Error */
	return;
}

void GameApp::closeScreen( void )
{
	ShowCursor( TRUE );

	if( this->IpDD != NULL )
	{
		if( IpDDSBack != NULL )
		{
			this->IpDDSBack->Release( );
			this->IpDDSBack = NULL;
		}

		if( IpDDSPrimary != NULL )
		{
			this->IpDDSPrimary->Release( );
			this->IpDDSPrimary = NULL;
		}

		this->IpDD->Release( );
		this->IpDD = NULL;
	}
}


/* * * * Accessor Methods * * * */

short GameApp::getWidth( void )
{
	return this->pageWidth;
}

short GameApp::getHeight( void )
{
	return this->pageHeight;
}

short GameApp::getDepth( void )
{
	return this->pageDepth;
}

short GameApp::getFlags( void )
{
	return this->Flags;
}

char *GameApp::getBasePtr( void )
{
	return this->pageBase;
}

long GameApp::getBytesPerRow( void )
{
	return this->pageBPR;
}


/* * * * Mutator Methods * * * */

void GameApp::setUpdateRect( short x1, short y1, short x2, short y2 )
{
	SetRect( &this->updateRect, x1, y1, x2, y2 );
}


/* * * * Screen Draw Methods * * * */

/* beginDraw Constants */
const short DrawOnBackBuf	= 0x0001;
const short NoVBLSync		= 0x0002;

/* endDraw Constants */
const short NoFlip			= 0x0001;

void GameApp::beginDraw( void )
{
	DDSURFACEDESC		ddsd;
	HRESULT				ddrval;

	ddsd.dwSize		=	sizeof( DDSURFACEDESC );

	do
	{
		ddrval = IpDDSPrimary->Lock( NULL, &ddsd, 0, NULL );
	} while( ddrval == DDERR_WASSTILLDRAWING );

	this->pageBase = (char *) ddsd.lpSurface;
	this->pageBPR  = ddsd.lPitch;

//	IpDD->WaitForVerticalBlank( DDWAITVB_BLOCKEND, 0 );
}

void GameApp::endDraw( void )
{
	IpDDSPrimary->Unlock( NULL );
}


/* * * * PixelBased Methods * * * */

void GameApp::putPixel8( short x, short y, char c )
{
	this->pageBase[ y * this->pageBPR + x ] = c;
}

void GameApp::putPixel16( short x, short y, short c )
{
}

void GameApp::putPixel32( short x, short y, long c )
{
}

char GameApp::getPixel8( short x, short y )
{
	return this->pageBase[ y * this->pageBPR + x ];
}

short GameApp::getPixel16( short x, short y )
{
	return 0;
}

long GameApp::getPixel32( short x, short y )
{
	return 0L;
}


/* * * * Palette Methods * * * */

void GameApp::setRGBAtIndex( short red, short green, short blue, short index )
{
	this->ape[ index ].peRed	=	(unsigned char) red;
	this->ape[ index ].peGreen	=	(unsigned char) green;
	this->ape[ index ].peBlue	=	(unsigned char) blue;
}

void GameApp::getRGBAtIndex( short *red, short *green, short *blue, short index )
{
	*red	= (short) this->ape[ index ].peRed;
	*green	= (short) this->ape[ index ].peGreen;
	*blue	= (short) this->ape[ index ].peBlue;
}

void GameApp::updatePalette( void )
{
	if( ddpal != NULL )
		ddpal->Release( );

	if( IpDD->CreatePalette( DDPCAPS_8BIT, ape, &ddpal, NULL ) != DD_OK )
	{
		IpDDSPrimary->Release( );
		IpDD->Release( );
		return;		
	}

	IpDDSPrimary->SetPalette( ddpal );
	ddpal->Release( );
}



/* * * * Game Specific Methods * * * */

void GameApp::pause( void )
{
}

void GameApp::quit( void )
{
	this->Exit = true;
}


/* * * * Windows Specific Methods * * * */

void GameApp::setHInstance( HINSTANCE hinstance )
{
	this->hInstance = hinstance;
}

bool GameApp::systemTask( void )
{
	if( this->Exit == true )
		return false;

	if( ! GetMessage( &msg, NULL, 0, 0 ) )
	{
		return false;
		// return msg.wParam;
	}

	TranslateMessage( &msg );
	DispatchMessage( &msg );

	return true;
}
