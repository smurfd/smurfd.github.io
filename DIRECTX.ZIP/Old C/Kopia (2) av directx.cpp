/*
 * directx.cpp - 1998/02/17
 *
 * Copyright (C) 1998 Johan Sorlin, spocke@algonet.se
 *
 * This program shows how to setup and make a fullscreen
 * graphical application under Win32. It uses DirectX for
 * fast blittings and mode switching.
 *
 * No Updates
 *
 */

/* Windows Specific Includes */
#include <ddraw.h>
#include <windows.h>
#include <windowsx.h>

/* ANSI-C Includes */
#include <stdio.h>
#include <string.h>
#include <time.h>

/* DirectDraw Globals */
LPDIRECTDRAW			IpDD;
LPDIRECTDRAWSURFACE		IpDDSPrimary;
LPDIRECTDRAWSURFACE		IpDDSBack;

/* Function Prototypes */
LRESULT CALLBACK WndProc( HWND, UINT, WPARAM, LPARAM );
void DrawFrame( unsigned char *base, long bytes_per_row );

/* * * * Functions * * * */

bool InitDirectDraw( HWND hwnd, DWORD width, DWORD height, DWORD depth )
{
	HRESULT		ddrval;

	ddrval = DirectDrawCreate( NULL, &IpDD, NULL );
	if( ddrval != DD_OK )
	{
		return false;
	}

	ddrval = IpDD->SetCooperativeLevel( hwnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN );
	if( ddrval != DD_OK )
	{
		IpDD->Release( );
		return false;
	}

	ddrval = IpDD->SetDisplayMode( width, height, depth );
	if( ddrval != DD_OK )
	{
		IpDD->Release( );
		return false;
	}

	return true;
}

bool CreatePrimarySurface( void )
{
	DDSURFACEDESC	ddsd;
	DDSCAPS			ddscaps;
	HRESULT			ddrval;

	memset( &ddsd, 0, sizeof( DDSURFACEDESC ) );
	ddsd.dwSize				= sizeof( DDSURFACEDESC );
	ddsd.dwFlags			= DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
	ddsd.ddsCaps.dwCaps		= DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX;
	ddsd.dwBackBufferCount	= 1;

	ddrval = IpDD->CreateSurface( &ddsd, &IpDDSPrimary, NULL );
	if( ddrval != DD_OK )
	{
		IpDD->Release( );
		return false;
	}

	ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
	ddrval = IpDDSPrimary->GetAttachedSurface( &ddscaps, &IpDDSBack );
	if( ddrval != DD_OK )
	{
		IpDDSPrimary->Release( );
		IpDD->Release( );
		return false;
	}

	return true;
}

void ShutDownDDraw( void )
{
	ShowCursor( TRUE );
	IpDDSPrimary->Release( );
	IpDD->Release( );
}

unsigned char *LockBackBuf( LPDIRECTDRAWSURFACE pSurface, LONG *bytes_per_row )
{
	DDSURFACEDESC		ddsd;
	HRESULT				ddrval;

	ddsd.dwSize		=	sizeof( DDSURFACEDESC );

	do
	{
		ddrval = pSurface->Lock( NULL, &ddsd, 0, NULL );
	} while( ddrval == DDERR_WASSTILLDRAWING );

	*bytes_per_row = ddsd.lPitch; 

	return ddrval == DD_OK ? (unsigned char *) ddsd.lpSurface : NULL;
}

void UnLockBackBuf( LPDIRECTDRAWSURFACE pSurface )
{
	pSurface->Unlock( NULL );
}

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow )
{
	WNDCLASSEX		wndclass;
	MSG				msg;
	HWND			hwnd;
	static char		szAppName[] = "My First Appl";

	/* Setup Window Class Data */
	wndclass.cbSize			= sizeof( wndclass );
	wndclass.style			= CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc	= WndProc;
	wndclass.cbClsExtra		= 0;
	wndclass.cbWndExtra		= 0;
	wndclass.hInstance		= hInstance;
	wndclass.hIcon			= LoadIcon( NULL, IDI_APPLICATION );
	wndclass.hIconSm		= LoadIcon( NULL, IDI_APPLICATION );
	wndclass.hCursor		= LoadCursor( NULL, IDC_ARROW );
	wndclass.hbrBackground	= (HBRUSH) GetStockObject( WHITE_BRUSH );
	wndclass.lpszMenuName	= NULL;
	wndclass.lpszClassName	= szAppName;

	/* Register Window Class to system */
	if (!(RegisterClassEx (&wndclass)))			
		return FALSE;

	/* Create the main Window */
	hwnd = CreateWindowEx (
		WS_EX_APPWINDOW,				 // Extended Window Style
		szAppName,						 // Window Class Name
		"Skelo32",						 // Window Caption
		WS_POPUP | WS_VISIBLE,			 // Window Style
		0,								 // Initial X Pos
		0,								 // Initial Y Pos
		GetSystemMetrics( SM_CXSCREEN ), // Initial X Size
		GetSystemMetrics( SM_CYSCREEN ), // Initial Y Size
		NULL,							 // Parent Window Handle
		NULL,							 // Window Menu Handle
		hInstance,						 // Program Instance Handle
		NULL);							 // Creation Paramaters

	/* Initialize DirectX and make main surface */
	InitDirectDraw( hwnd, 640, 480, 8 );
	CreatePrimarySurface( );

	/* Show window and update */
	ShowWindow( hwnd, iCmdShow );	
	UpdateWindow( hwnd );

	while( TRUE )						
	{
		if( !GetMessage( &msg, NULL, 0, 0 ) )
		{
			MessageBox( NULL, "CU L8-)TER!!!", "Quit Message!!", MB_YESNO );
			return msg.wParam;
		}

		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}
}

long frameCounter = 0L;

LRESULT CALLBACK WndProc( HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
	static BOOL		fFirstPaint = TRUE;

	switch( iMsg )
	{
		case WM_LBUTTONUP:
			ShutDownDDraw( );
			PostMessage( hwnd, WM_CLOSE, 0, 0 );
			return 0;
		break;

		case WM_KEYDOWN:
			{
/*				char temp[100];

				sprintf( temp ,"%d", wParam );
				MessageBox( hwnd, temp, "", MB_YESNO );

				switch( wParam )
				{
					case VK_ESCAPE:
					case VK_F12:
						PostMessage( hwnd, WM_CLOSE, 0, 0 );
						return 0;
					break;
				}
*/
				return 0;
			}
		break;

		case WM_PAINT:
			{
				unsigned char	*baseAddr;
				long			bpr;

				frameCounter++;

				if( frameCounter > 100L )
				{
					frameCounter = 0;

					baseAddr = LockBackBuf( IpDDSPrimary, &bpr );
					if( baseAddr != NULL )
					{
						IpDD->WaitForVerticalBlank( DDWAITVB_BLOCKEND, 0 );
						//DrawFrame( baseAddr, bpr );
						UnLockBackBuf( IpDDSPrimary );
					}
				}

				if( fFirstPaint )
				{
					ShowCursor( FALSE );
					fFirstPaint = FALSE;
				}

				return 0;
			}
		break;

		case WM_DESTROY:
			PostQuitMessage( 0 );
			return 0;
		break;
	}

	return DefWindowProc( hwnd, iMsg, wParam, lParam );
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

short pelle = 0;

void DrawFrame( unsigned char *base, long bytes_per_row )
{
	short		x,y;

	pelle++;

	for( y=0; y<480; y++ )
	for( x=0; x<640; x++ )
		base[ y * bytes_per_row + x] = (unsigned char) (x * y) * pelle;
}


