/*
 * directx.cpp - 1998/02/17
 *
 * Copyright (C) 1998 Johan Sorlin, spocke@algonet.se
 *
 * This program shows how to setup and make a fullscreen
 * graphical application under Win32. It uses DirectX for
 * fast blittings and mode switching.
 *
 * No Updates
 *
 */

/* Windows Specific Includes */
#include <ddraw.h>
#include <windows.h>
#include <windowsx.h>

/* ANSI-C Includes */
#include <stdio.h>
#include <string.h>
#include <time.h>

class GameApp {
public:
	/* Constructor & DeConstrucor */
	GameApp( );
	~GameApp( );

	/* Screen Specific Methods */
	void openScreen( short width, short height, short depth, short flags );
	void closeScreen( void );

	/* Accessor Methods */
	short getWidth( void );
	short getHeight( void );
	short getDepth( void );
	short getFlags( void );
	char  *getBasePtr( void );
	long  getBytesPerRow( void );

	/* Mutator Methods */
	void setUpdateRect( short x1, short y1, short x2, short y2 );

	/* Screen Draw Methods */
	void beginDraw( void );
	void endDraw( void );

	/* PixelBased Methods */
	void  inline putPixel8( short x, short y, char c );
	void  inline putPixel16( short x, short y, short c );
	void  inline putPixel32( short x, short y, long c );
	char  inline getPixel8( short x, short y );
	short inline getPixel16( short x, short y );
	long  inline getPixel32( short x, short y );

	/* Palette Methods */
	void setRGBAtIndex( short red, short green, short blue, short index );
	void getRGBAtIndex( short *red, short *green, short *blue, short index );
	void updatePalette( void );

	/* Game Specific Methods */
	void pause( void );
	void quit( void );

	/* Windows Specific Methods */
	void setHInstance( HINSTANCE hinstance );
	bool systemTask( void );

private:
	/* Current Page Data */
	char		*pageBase;
	long		pageBPR;
	short		pageWidth;
	short		pageHeight;
	short		pageDepth;
	char		**pageRows;

	/* Other GameApp Data */
	short		Flags;
	bool		Exit;
	RECT		updateRect;

	/* DirectDraw Data */
	LPDIRECTDRAW			IpDD;
	LPDIRECTDRAWSURFACE		IpDDSPrimary;
	LPDIRECTDRAWSURFACE		IpDDSBack;
	IDirectDrawPalette		*ddpal;
	PALETTEENTRY			ape[ 256 ];

	/* MainWindow Data */
	WNDCLASSEX				wndclass;
	MSG						msg;
	HWND					hwnd;
	char					szAppName[32];
	HINSTANCE				hInstance;
};

short		pelle = 0;
GameApp		game;

LRESULT CALLBACK WndProc( HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
	static BOOL		fFirstPaint = TRUE;

	switch( iMsg )
	{
		case WM_LBUTTONUP:
			game.quit( );
			PostMessage( hwnd, WM_CLOSE, 0, 0 );
			return 0;
		break;

		case WM_PAINT:
			{
				return 0;
			}
		break;

		case WM_DESTROY:
			PostQuitMessage( 0 );
			return 0;
		break;
	}

	return DefWindowProc( hwnd, iMsg, wParam, lParam );
}



/* * * * * * * * */

#define TRUE_WARP

#define MAXSTARS		20000
#define WARP			1
#define MAX_SPEED		8

// * * MAXX,MAXY is defines in FastGFX.h
#define MEDX			320
#define MEDY			200

#define MAXX			640
#define MAXY			480
#define MAXZ			255

#define X_OFF			(MAXX/2)
#define Y_OFF			(MAXY/2)
#define Z_OFF			255

extern void	InitStars( void );
extern void	CloseStars( void );
extern void	CreateStar( short Star_Nr );
extern void	UpdateStars( void );
extern void	main( void );

///////////////////////////// GLOBALS //////////////////////////////

typedef struct {
	short		x;				// x,y,z in offset cords
	short		y;
	short		z;

	short		ox;				// ox,oy in screen cords
	short		oy;

#ifndef TRUE_WARP
	short		v;
#endif
} StarFormat;

static StarFormat 	*Stars = NULL;

///////////////////////////// FUNCTIONS /////////////////////////////

short rnd( short min, short max )
{
	return( (rand( ) % (max-min)) + min );
}

void InitStars( void )
{
	short	i;

	Stars = (StarFormat *) malloc( sizeof( StarFormat ) * (long) (MAXSTARS+1L) );
	if( Stars == NULL )
	{
		// ErrorMessage( "\pGive me more memory 8-)",0 );
		exit( -1 );
	}

	for( i=0;i<=MAXSTARS;i++ )
	{
		Stars[ i ].x	=	rnd( -MEDX,MEDX );
		Stars[ i ].y	=	rnd( -MEDY,MEDY );
		Stars[ i ].z	=	rnd( 2,255 );

		Stars[ i ].ox	=	0;
		Stars[ i ].oy	=	0;

#ifndef TRUE_WARP
		Stars[ i ].v	=	rnd( 1,MAX_SPEED );
#endif
	}
}

void CloseStars( void )
{
	if( Stars != NULL )
	{
		free( (void *) Stars );
		Stars = NULL;
	}
}

void CreateStar( short Star_Nr )
{
	Stars[ Star_Nr ].x	=	rnd( -MEDX,MEDX );
	Stars[ Star_Nr ].y	=	rnd( -MEDY,MEDY );
	Stars[ Star_Nr ].z	=	MAXZ;

#ifndef TRUE_WARP
	Stars[ Star_Nr ].v	=	rnd( 1,MAX_SPEED );
#endif
}

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow )
{
	short			x,y,i, firstf = 0;

	game.setHInstance( hInstance );
	game.openScreen( 640, 480, 8, 0 );
	ShowCursor( FALSE );

	for( i=0; i<256; i++ )
		game.setRGBAtIndex( i, i, i, i );

	game.updatePalette( );

	InitStars( );

	while( game.systemTask( ) )						
	{
		game.beginDraw( );

/*		pelle++;

		for( y=0; y<480; y++ )
		for( x=0; x<640; x++ )
			game.putPixel8( x, y, (char) y + pelle );
*/

	short		i,nx,ny;

	for( i=0;i<=MAXSTARS;i++ )
	{
		if( Stars[ i ].z > 0 )
		{
			nx	=	( ( Stars[ i ].x << 7 ) / Stars[ i ].z ) + X_OFF;
			ny	=	( ( Stars[ i ].y << 7 ) / Stars[ i ].z ) + Y_OFF;

			if( (nx > 0 && nx < MAXX) && (ny > 0 && ny < MAXY) )
			{
				game.putPixel8( Stars[ i ].ox, Stars[ i ].oy,(char) 0 );
				game.putPixel8( nx, ny,(char) 255-Stars[ i ].z );

				Stars[ i ].ox = nx;
				Stars[ i ].oy = ny;

#ifdef TRUE_WARP
				Stars[ i ].z -= WARP;
#else
				Stars[ i ].z -= Stars[ i ].v;
#endif
			}
			else
				CreateStar( i );
		}
		else
			CreateStar( i );
	}

		if( firstf < 5 )
		{
			for( y=0; y<480; y++ )
			for( x=0; x<640; x++ )
				game.putPixel8( x, y, (char) 1 );

			firstf++;
		}

		game.endDraw( );
	}

	CloseStars( );
	game.closeScreen( );

	return 0;
}
