/*
 * directx.cpp - 1998/02/17
 *
 * Copyright (C) 1998 Johan Sorlin, spocke@algonet.se
 *
 * This program shows how to setup and make a fullscreen
 * graphical application under Win32. It uses DirectX for
 * fast blittings and mode switching.
 *
 * No Updates
 *
 */

#include <ddraw.h>
#include <windows.h>
#include <windowsx.h>

#include <stdio.h>
#include <string.h>
#include <time.h>

LRESULT CALLBACK WndProc( HWND, UINT, WPARAM, LPARAM );

LPDIRECTDRAW			IpDD;
LPDIRECTDRAWSURFACE		IpDDSPrimary;
LPDIRECTDRAWSURFACE		IpDDSBack;

bool InitDirectDraw( HWND hwnd )
{
	HRESULT		ddrval;

	ddrval = DirectDrawCreate( NULL, &IpDD, NULL );
	if( ddrval != DD_OK )
	{
		return false;
	}

	ddrval = IpDD->SetCooperativeLevel( hwnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN );
	if( ddrval != DD_OK )
	{
		IpDD->Release( );
		return false;
	}

	ddrval = IpDD->SetDisplayMode( 640, 480, 8 );
	if( ddrval != DD_OK )
	{
		IpDD->Release( );
		return false;
	}

	return true;
}

bool CreatePrimarySurface( void )
{
	DDSURFACEDESC	ddsd;
	DDSCAPS			ddscaps;
	HRESULT			ddrval;

	memset( &ddsd, 0, sizeof( DDSURFACEDESC ) );
	ddsd.dwSize				= sizeof( DDSURFACEDESC );
	ddsd.dwFlags			= DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
	ddsd.ddsCaps.dwCaps		= DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX;
	ddsd.dwBackBufferCount	= 1;

	ddrval = IpDD->CreateSurface( &ddsd, &IpDDSPrimary, NULL );
	if( ddrval != DD_OK )
	{
		IpDD->Release( );
		return false;
	}

	ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
	ddrval = IpDDSPrimary->GetAttachedSurface( &ddscaps, &IpDDSBack );
	if( ddrval != DD_OK )
	{
		IpDDSPrimary->Release( );
		IpDD->Release( );
		return false;
	}

	return true;
}

void ShutDownDDraw( void )
{
	ShowCursor( TRUE );
	IpDDSPrimary->Release( );
	IpDD->Release( );
}

unsigned char *LockBackBuf( LPDIRECTDRAWSURFACE pSurface, LONG *bytes_per_row )
{
	DDSURFACEDESC		ddsd;
	HRESULT				ddrval;

	ddsd.dwSize		=	sizeof( DDSURFACEDESC );

	do
	{
		ddrval = pSurface->Lock( NULL, &ddsd, 0, NULL );
	} while( ddrval == DDERR_WASSTILLDRAWING );

	*bytes_per_row = ddsd.lPitch; 

	return ddrval == DD_OK ? (unsigned char *) ddsd.lpSurface : NULL;
}

void UnLockBackBuf( LPDIRECTDRAWSURFACE pSurface )
{
	pSurface->Unlock( NULL );
}

long pelle = 0;

void DrawToScreen( void )
{
	short			x,y;
	unsigned char	*baseAddr;
	LONG			bpr;

	baseAddr = LockBackBuf( IpDDSPrimary, &bpr );
	if( baseAddr != NULL )
	{
		long tim = time( NULL );

		pelle++;

		for( y=0; y<480; y++ )
		for( x=0; x<640; x++ )
			baseAddr[ y * bpr + x] = (unsigned char) (x * y) * pelle + tim;

		UnLockBackBuf( IpDDSPrimary );
	}
}

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow )
{
	WNDCLASSEX		wndclass;
	MSG				msg;
	HWND			hwnd;
	static char		szAppName[] = "My First Appl";

	/* Setup Window Class Data */
	wndclass.cbSize			= sizeof( wndclass );
	wndclass.style			= CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc	= WndProc;
	wndclass.cbClsExtra		= 0;
	wndclass.cbWndExtra		= 0;
	wndclass.hInstance		= hInstance;
	wndclass.hIcon			= LoadIcon( NULL, IDI_APPLICATION );
	wndclass.hIconSm		= LoadIcon( NULL, IDI_APPLICATION );
	wndclass.hCursor		= LoadCursor( NULL, IDC_ARROW );
	wndclass.hbrBackground	= (HBRUSH) GetStockObject( WHITE_BRUSH );
	wndclass.lpszMenuName	= NULL;
	wndclass.lpszClassName	= szAppName;

	/* Register Window Class to system */
	if (!(RegisterClassEx (&wndclass)))			
		return FALSE;

	/* Create the main Window */
	hwnd = CreateWindowEx (
		WS_EX_APPWINDOW,				 // Extended Window Style
		szAppName,						 // Window Class Name
		"Skelo32",						 // Window Caption
		WS_POPUP | WS_VISIBLE,			 // Window Style
		0,								 // Initial X Pos
		0,								 // Initial Y Pos
		GetSystemMetrics( SM_CXSCREEN ), // Initial X Size
		GetSystemMetrics( SM_CYSCREEN ), // Initial Y Size
		NULL,							 // Parent Window Handle
		NULL,							 // Window Menu Handle
		hInstance,						 // Program Instance Handle
		NULL);							 // Creation Paramaters

	/* Initialize DirectX and make main surface */
	InitDirectDraw( hwnd );
	CreatePrimarySurface( );

	/* Show window and update */
	ShowWindow (hwnd, iCmdShow);	
	UpdateWindow (hwnd);

	while( TRUE )						
	{
		if( !GetMessage( &msg, NULL, 0, 0 ) )
		{
			MessageBox( NULL, "CU L8-)TER!!!", "Quit Message!!", MB_OK );
			return msg.wParam;
		}

		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}
}

LRESULT CALLBACK WndProc( HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
	HDC				hdc;				// Handle of a device context (DC).
	PAINTSTRUCT		ps;
	RECT			rect;
	static BOOL		fFirstPaint = TRUE;

	switch( iMsg )
	{
		case WM_LBUTTONUP:
			ShutDownDDraw( );
			PostMessage( hwnd, WM_CLOSE, 0, 0 );
			return 0;
		break;

		case WM_KEYDOWN:
			{
				PostMessage( hwnd, WM_PAINT, 0, 0 );
/*
				char temp[100];

				sprintf( temp ,"%d", wParam );
				MessageBox( hwnd, temp, "", MB_OK );

				switch( wParam )
				{
					case VK_ESCAPE:
					case VK_F12:
						PostMessage( hwnd, WM_CLOSE, 0, 0 );
						return 0;
					break;
				}*/
				return 0;
			}
		break;

		case WM_PAINT:
			{
/*				hdc = BeginPaint( hwnd, &ps );
				GetClientRect( hwnd, &rect );

				DrawText( hdc, "Hello World!!", -1, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER );

				for( y=0; y<100; y++ )
				for( x=0; x<100; x++ )
					SetPixel( hdc, x, y, RGB( 0, 0, 255 ) );

				EndPaint( hwnd, &ps );*/
		
				if( fFirstPaint )
				{
					ShowCursor( FALSE );
					fFirstPaint = FALSE;
				}

				DrawToScreen( );

				return 0;
			}
		break;

		case WM_DESTROY:
			PostQuitMessage( 0 );
			return 0;
		break;
	}

	return DefWindowProc( hwnd, iMsg, wParam, lParam );
}
