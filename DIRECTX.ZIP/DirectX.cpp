/*
 * DirectX.cpp - 1998/03/04
 *
 * Copyright (C) 1998 Johan Sorlin, spocke@algonet.se
 *
 * This file contains a few functions to easy up direct draw
 * devolopment, it has functions for initializing gmodes, making
 * surfaces, geting and setting palettes etc...
 *
 * To use these functions, just include the following files
 * to your project:
 *
 * DirectX.c - This file
 * DirectX.h - Header file for this one
 * DDRAW.LIB - The main DirectDraw Lib from MicroSoft
 *
 * No Updates
 *
 */

/* Windows Specific Includes */
#include <ddraw.h>
#include <windows.h>
#include <windowsx.h>

#include "DirectX.hpp"

/* * * * Direct Draw Functsions * * * */

LPDIRECTDRAW OpenDirectDraw( HWND hwnd, short width, short height, short depth )
{
	HRESULT			ddrval;
	LPDIRECTDRAW	IpDD;

	/* Create DirectDraw Main Object */
	ddrval = DirectDrawCreate( NULL, &IpDD, NULL );
	if( ddrval != DD_OK )
	{
		/* Error */
		return FALSE;
	}

	/* Set to full screen */
	ddrval = IpDD->SetCooperativeLevel( hwnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN );
	if( ddrval != DD_OK )
	{
		/* Error */
		IpDD->Release( );
		return NULL;
	}

	/* Switch resulution and depth */
	ddrval = IpDD->SetDisplayMode( width, height, depth );
	if( ddrval != DD_OK )
	{
		/* Error */
		IpDD->Release( );
		return NULL;
	}

	return IpDD;
}

void CloseDirectDraw( LPDIRECTDRAW lpddraw )
{
	lpddraw->Release( );
	lpddraw = NULL;
}


/* * * * Direct Draw Surface Functions * * * */

short GetSurfaces( LPDIRECTDRAW lpddraw, LPDIRECTDRAWSURFACE *dds_primary,
				 LPDIRECTDRAWSURFACE *dds_back )
{
	HRESULT			ddrval;
	DDSURFACEDESC	ddsd;
	DDSCAPS			ddscaps;

	/* Set and Creante main surface */
	memset( &ddsd, 0, sizeof( DDSURFACEDESC ) );
	ddsd.dwSize				= sizeof( DDSURFACEDESC );
	ddsd.dwFlags			= DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
	ddsd.ddsCaps.dwCaps		= DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX;
	ddsd.dwBackBufferCount	= 1;

	ddrval = lpddraw->CreateSurface( &ddsd, dds_primary, NULL );
	if( ddrval != DD_OK )
	{
		/* Error */
		lpddraw->Release( );
		return false;
	}

	/* Get Attached back buffer for page flipping */
	ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
	ddrval = (*dds_primary)->GetAttachedSurface( &ddscaps, dds_back );
	if( ddrval != DD_OK )
	{
		/* Error */
		(*dds_primary)->Release( );
		lpddraw->Release( );
		return false;
	}

	return true;
}

void ReleaseSurface( LPDIRECTDRAWSURFACE surface )
{
	if( surface != NULL )
	{
		surface->Release( );
		surface = NULL;
	}
}

void LockSurface( LPDIRECTDRAWSURFACE surface, char **base, long *bytes_per_row )
{
	DDSURFACEDESC		ddsd;
	HRESULT				ddrval;

	ddsd.dwSize		=	sizeof( DDSURFACEDESC );

	do
	{
		ddrval = surface->Lock( NULL, &ddsd, 0, NULL );
	} while( ddrval == DDERR_WASSTILLDRAWING );

	*base			=	(char *) ddsd.lpSurface;
	*bytes_per_row	=	ddsd.lPitch;
}

void UnlockSurface( LPDIRECTDRAWSURFACE surface )
{
	surface->Unlock( NULL );
}

LPDIRECTDRAWSURFACE CreateOffScreenSurface( LPDIRECTDRAW lpddraw, short width, short height )
{
	DDSURFACEDESC			ddsd;
	IDirectDrawSurface		*pdds;

	/* Initialize ddsd struct */
	ZeroMemory( &ddsd, sizeof( DDSURFACEDESC ) );
	ddsd.dwSize			= sizeof( DDSURFACEDESC );
	ddsd.dwFlags		= DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps	= DDSCAPS_OFFSCREENPLAIN;
	ddsd.dwWidth		= width;
	ddsd.dwHeight		= height;

	/* Create OffScreen surface */
	if( lpddraw->CreateSurface( &ddsd, &pdds, NULL ) != DD_OK )
		return NULL;

	/* On succes, return pointer */
	return pdds;
}


/* * * * Direct Draw Palette Functions * * * */

void SetRGBAtIndex( LPPALETTEENTRY palette, BYTE red, BYTE green, 
				   BYTE blue, BYTE index )
{
	palette[index].peFlags	= PC_EXPLICIT;
	palette[index].peRed	= red;
	palette[index].peGreen	= green;
	palette[index].peBlue	= blue;
}

void GetRGBAtIndex( LPPALETTEENTRY palette, BYTE *red, BYTE *green, 
				   BYTE *blue, BYTE index )
{
	*red	= palette[index].peRed;
	*green	= palette[index].peGreen;
	*blue	= palette[index].peBlue;
}

LPDIRECTDRAWPALETTE MakePalette( LPDIRECTDRAW lpddraw, LPPALETTEENTRY in_pal )
{
	LPDIRECTDRAWPALETTE		ddpal;

	/* Create Direct Draw Palette */
	if( lpddraw->CreatePalette( DDPCAPS_8BIT, in_pal, &ddpal, NULL ) != DD_OK )
		return NULL;

	/* On succes, return pointer */
	return ddpal;
}





