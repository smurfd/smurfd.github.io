/*
*
*
*
*/

/* ANSI-C Includes */
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>

/* Local includes */
#include "GameApp.hpp"


/* * * * Class Definition * * * */

class Stars3D {
public:
	/* Constructor & DeConstructor */
	Stars3D( );
	~Stars3D( );

	/* Making/Disposing Methods */
	void make( short num_stars, short max_distance );
	void dispose( );

	/* Drawing Methods */
	void rotate( short angle_x, short angle_y, short angle_z );
	void draw( short off_x, short off_y, short off_z );

private:
	/* Private Methods */
	int rnd( int min, int max );

	/* Stars3D Main Data */
	struct Pixel3D {
		short	x;
		short	y;
		short	z;
		short	c;
		short	x_add;

		short	nx;
		short	ny;
		short	nz;

		short	old_x;
		short	old_y;
	} *Stars;

	short	Angle_X;
	short	Angle_Y;
	short	Angle_Z;
	short	Num_Stars;

	double	*sin_tab;
	double	*cos_tab;
};



/* * * * Constructor & DeConstructor * * * */

Stars3D::Stars3D( )
{
	/* Initialize ZStars Main Data */
	this->Stars			=	NULL;
	this->Angle_X		=	0;
	this->Angle_Y		=	0;
	this->Angle_Z		=	0;
	this->Num_Stars		=	0;
	this->sin_tab		=	NULL;
	this->cos_tab		=	NULL;
}

Stars3D::~Stars3D( )
{
	this->dispose( );
}


/* * * * Initializing Methods * * * */

void Stars3D::make( short num_stars, short max_distance )
{
	int		i;

	/* If allready allocated, then dispose */
	this->dispose( );

	/* Allocate Space for StarsX */
	this->Stars = (struct Pixel3D *) malloc( (long) num_stars * sizeof( struct Pixel3D ) );
	if( this->Stars == NULL )
	{
		this->dispose( );
		return;
	}

	this->sin_tab = (double *) malloc( (long) 360 * sizeof( double ) );
	if( this->sin_tab == NULL )
	{
		this->dispose( );
		return;
	}

	this->cos_tab = (double *) malloc( (long) 360 * sizeof( double ) );
	if( this->cos_tab == NULL )
	{
		this->dispose( );
		return;
	}

	#define sinq( ang ) sin( (ang) * 0.01745f ) 
	#define cosq( ang ) cos( (ang) * 0.01745f )

	for( i=0; i<360; i++ )
	{
		this->sin_tab[ i ] = (double) sinq( i );
		this->cos_tab[ i ] = (double) cosq( i );		
	}

	this->Num_Stars = num_stars;

	for( i=0; i<this->Num_Stars; i++ )
	{
		this->Stars[i].x		=	rnd( -100, 100 );
		this->Stars[i].y		=	rnd( -100, 100 );
		this->Stars[i].z		=	rnd( -100, 100 );
		this->Stars[i].c		=	0;
		this->Stars[i].old_x	=	0;
		this->Stars[i].old_y	=	0;
		this->Stars[i].x_add	=	1;
	}
}

void Stars3D::dispose( )
{
	/* If allocated sin_tab */
	if( this->sin_tab != NULL )
	{
		free( (void *) this->sin_tab );
		this->sin_tab = NULL;
	}

	/* If allocated cos_tab */
	if( this->cos_tab != NULL )
	{
		free( (void *) this->cos_tab );
		this->cos_tab = NULL;
	}

	/* If allocated Stars  */
	if( this->Stars   != NULL )
	{
		free( (void *) this->Stars  );
		this->Stars  = NULL;
	}
}

void Stars3D::rotate( short angle_x, short angle_y, short angle_z )
{
		double rrx, rry, rrz, rx, ry, rz;
		short bx, by, bz, i;

		for( i=0; i<this->Num_Stars; i++ )
		{
			bx = this->Stars[i].x;
			by = this->Stars[i].y;
			bz = this->Stars[i].z;

			ry = cosq( angle_x ) * by - sinq(angle_x) * bz;
			rz = sinq( angle_x ) * by + cosq(angle_x) * bz;
	
			rx =  cosq( angle_y )  * bx + sinq(angle_y) * rz;
			rrz = -sinq( angle_y ) * bx + cosq(angle_y) * rz;

			rrx = cosq(angle_z) * rx - sinq(angle_z) * ry;
			rry = sinq(angle_z) * rx + cosq(angle_z) * ry;

			this->Stars[i].nx = rrx;
			this->Stars[i].ny = rry;
			this->Stars[i].nz = rrz;

			if( this->Stars[i].x > 100 )
			{
				this->Stars[i].x = -100;
				// this->Stars[i].x -= 1;
				// this->Stars[i].x_add *= -1;
			}
			else
				this->Stars[i].x += this->Stars[i].x_add;

//			if( this->Stars[i].z > 100 )
//				this->Stars[i].z = -100;
//			else
//				this->Stars[i].z++;
		}
}

void Stars3D::draw( short off_x, short off_y, short off_z )
{
	int		i, sx, sy;

	game.lockPage( FrontPage );

	off_z = 400;

	for( i=0; i<this->Num_Stars; i++ )
	{
		sx	=	( ( this->Stars[i].nx << 8 ) / (this->Stars[i].nz + off_z) ) + 320;
		sy	=	( ( this->Stars[i].ny << 8 ) / (this->Stars[i].nz + off_z) ) + 240;

		game.putPixel8( this->Stars[i].old_x, this->Stars[i].old_y, 0 );
		game.putPixel8( sx, sy, 255 - (this->Stars[i].nz + 100) );

		this->Stars[i].old_x = sx;
		this->Stars[i].old_y = sy;
	}

	game.unlockPage( FrontPage );
}

int Stars3D::rnd( int min, int max )
{
	return( (rand( ) % (max-min)) + min );
}
