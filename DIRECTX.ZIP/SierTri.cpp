/*
 * SierTri.cpp - v1.0 - 1998/03/12
 *
 * Copyright (C) Johan Sorlin, spocke@algonet.se
 *
 *
 * 1.0 - 1998/03/12 - This file was created
 *
 */

/* ANSI Includes */
#include <math.h>
#include <stdlib.h>

/* Local Includes */
#include "GameApp.hpp"


/* * * * Defines / Constants * * * */

static double	x = 0.0;
static double	y = 0.0;

/* * * * Functions * * * */

void Update_SierTri( RECT *r, short num_updates )
{
	short		n;
	short		xx,yy;

	game.lockPage( FrontPage );

	for( ; num_updates>=0; num_updates-- )
	{
		n = rand( ) % 201;

 		if( n < 50 )
 		{
    		x *= 0.5;
   			y *= 0.5;
 		}
 		
 		if( n > 50 && n < 100 )
 		{
    		x = 0.5 * (0.5+x);
    		y = 0.5 * (1+y);
  		}

  		if( n > 100 )
  		{
   			x = 0.5 * (1+x);
    		y = 0.5 * y;
  		}

		xx = (short) ( x * (double) ((r->right  - r->left) ) );
		yy = (short) ( y * (double) ((r->bottom - r->top) ) );

		if( xx > 0 && xx < 639 && yy > 0 && yy < 479 )
  			game.putPixel8( xx, yy, (BYTE) 128 );
  	}

  	game.unlockPage( FrontPage );
}
