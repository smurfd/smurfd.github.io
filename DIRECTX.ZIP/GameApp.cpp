/*
 * GameApp.cpp - 1998/03/03
 *
 * Copyright (C) 1998 Johan Sorlin, spocke@algonet.se
 *
 * This file contains the GameApp class, this class
 * provides a game programmer with a simple API with
 * functions to open a screen, page flipping, palette.
 *
 * No Updates
 *
 */

/* Windows Specific Includes */
#include <ddraw.h>
#include <windows.h>
#include <windowsx.h>

/* Local Includes */
#include "DirectX.hpp"

/* * * * User defined extern Function Prototypes * * * * */
extern LRESULT CALLBACK WndProc( HWND, UINT, WPARAM, LPARAM );

/* * * * GameApp Constants * * * */

const short FrontPage = 1;
const short BackPage  = 2;

/* * * * GameApp Class Definition * * * */

class GameApp {
public:
	/* Constructor & DeConstrucor */
	GameApp( );
	~GameApp( );

	/* Screen Specific Methods */
	void openScreen( short width, short height, short depth, short flags );
	void closeScreen( );

	/* Accessor Methods */
	short getWidth( );
	short getHeight( );
	short getDepth( );
	short getFlags( );

	/* Page Methods */
	void flipPages( );
	void lockPage( short page );
	void lockPage( short page, char **base, long *bytes_per_row );
	void unlockPage( short page );
	void clearPage( short page );

	/* Blitter Methods */
	void copyArea( short from_page, RECT *frect, short to_page, short x, short y );

	/* Sync Methods */
	void waitVBL( );

	/* PutPixel Methods */
	void  putPixel8( short x, short y, char c );
	void  putPixel16( short x, short y, short c );
	void  putPixel32( short x, short y, long c );

	/* GetPixel Methods */
	char  getPixel8( short x, short y );
	short getPixel16( short x, short y );
	long  getPixel32( short x, short y );

	/* Palette Methods */
	void setRGBAtIndex( BYTE red, BYTE green, BYTE blue, BYTE index );
	void getRGBAtIndex( BYTE *red, BYTE *green, BYTE *blue, BYTE index );
	void updatePalette( );

	/* Game Specific Methods */
	void pause( void );
	void quit( void );

	/* Windows Specific Methods */
	void setHInstance( HINSTANCE hinstance );
	bool systemTask( void );

private:
	/* GameApp Main Data */
	short		screenWidth;
	short		screenHeight;
	short		screenDepth;
	short		screenFlags;
	bool		ExitBool;
	bool		FirstFrame;

	/* Active Page Data */
	char		*pageBase;
	long		pageBPR;

	/* DirectDraw Data */
	LPDIRECTDRAW			IpDD;
	LPDIRECTDRAWSURFACE		IpDDSPrimary;
	LPDIRECTDRAWSURFACE		IpDDSBack;
	LPDIRECTDRAWPALETTE		IpDDPal;

	/* Main Window Data */
	WNDCLASSEX				wndclass;
	MSG						msg;
	HWND					hwnd;
	HINSTANCE				hInstance;
	char					szAppName[32];

	/* Main Palette Data */
	PALETTEENTRY			MainPalette[ 256 ];
};


/* * * * Definiton of the Main object * * * */

GameApp		game;


/* * * * Constructor & DeConstrucor * * * */

GameApp::GameApp( void )
{
	/* GameApp Main Data */
	this->screenWidth	=	0;
	this->screenHeight	=	0;
	this->screenDepth	=	0;
	this->screenFlags	=	0;
	this->ExitBool		=	false;
	this->FirstFrame	=	true;

	/* Active Page Data */
	this->pageBase		=	NULL;
	this->pageBPR		=	0L;

	/* DirectDraw Data */
	this->IpDD			=	NULL;
	this->IpDDSPrimary	=	NULL;
	this->IpDDSBack		=	NULL;
	this->IpDDPal		=	NULL;

	/* Main Window Data */
	this->hwnd			=	NULL;
	this->hInstance		=	NULL;
	strcpy( this->szAppName, "Game Shell App" );
}

GameApp::~GameApp( void )
{
	this->closeScreen( );
}


/* * * * Screen Specific Methods * * * */

void GameApp::openScreen( short width, short height, short depth, short flags )
{
	/* Setup Window Class Data */
	wndclass.cbSize			= sizeof( wndclass );
	wndclass.style			= CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc	= WndProc;	/* Must exist a WndProc in Main source */
	wndclass.cbClsExtra		= 0;
	wndclass.cbWndExtra		= 0;
	wndclass.hInstance		= hInstance;
	wndclass.hIcon			= LoadIcon( NULL, IDI_APPLICATION );
	wndclass.hIconSm		= LoadIcon( NULL, IDI_APPLICATION );
	wndclass.hCursor		= LoadCursor( NULL, IDC_ARROW );
	wndclass.hbrBackground	= (HBRUSH) GetStockObject( WHITE_BRUSH );
	wndclass.lpszMenuName	= NULL;
	wndclass.lpszClassName	= szAppName;

	/* Register Window Class to system */
	if( !(RegisterClassEx( &wndclass )) )
	{
		/* Error */
		throw (short) 1;
		return;
	}

	/* Create the Main Window */
	this->hwnd = CreateWindowEx(
		WS_EX_APPWINDOW,				 // Extended Window Style
		szAppName,						 // Window Class Name
		"Game App Shell",				 // Window Caption
		WS_POPUP | WS_VISIBLE,			 // Window Style
		0,								 // Initial X Pos
		0,								 // Initial Y Pos
		GetSystemMetrics( SM_CXSCREEN ), // Initial X Size
		GetSystemMetrics( SM_CYSCREEN ), // Initial Y Size
		NULL,							 // Parent Window Handle
		NULL,							 // Window Menu Handle
		0L,							 // Program Instance Handle
		NULL);							 // Creation Paramaters

	if( hwnd == NULL )
	{
		/* Error */
		this->quit( );
	}

	ShowWindow( hwnd, SW_SHOW );
	UpdateWindow( hwnd );
	SetFocus( hwnd );

	this->IpDD = OpenDirectDraw( this->hwnd, width, height, depth );
	if( this->IpDD == NULL )
	{
		this->closeScreen( );
		throw (short) 2;
		return;
	}

	if( ! GetSurfaces( this->IpDD, &this->IpDDSPrimary, &this->IpDDSBack ) )
	{
		CloseDirectDraw( this->IpDD );
		throw (short) 3;
		return;
	}

	/* Make Main Palette */
	this->IpDDPal = MakePalette( this->IpDD, this->MainPalette );
	IpDDSPrimary->SetPalette( this->IpDDPal );
	IpDDSBack->SetPalette( this->IpDDPal );

	/* Clear both pages */
	this->clearPage( FrontPage );
	this->clearPage( BackPage );

	/* Set Main Screen Data */
	this->screenWidth	=	width;
	this->screenHeight	=	height;
	this->screenDepth	=	depth;
	this->screenFlags	=	flags;

	/* No Error */
	return;
}

void GameApp::closeScreen( void )
{
	ShowCursor( TRUE );

	if( this->IpDDPal != NULL )
	{
		this->IpDDPal->Release( );
		this->IpDDPal = NULL;
	}

	if( this->IpDD != NULL )
	{
		IpDD->RestoreDisplayMode( );
		UpdateWindow( this->hwnd );
		ReleaseSurface( this->IpDDSBack );
		ReleaseSurface( this->IpDDSPrimary );
		this->IpDD->Release( );
		this->IpDD = NULL;
	}

	if( this->hwnd != NULL )
	{
		CloseWindow( this->hwnd );
		this->hwnd = NULL;
	}
}


/* * * * Accessor Methods * * * */

short GameApp::getWidth( void )
{
	return this->screenWidth;
}

short GameApp::getHeight( void )
{
	return this->screenHeight;
}

short GameApp::getDepth( void )
{
	return this->screenDepth;
}

short GameApp::getFlags( void )
{
	return this->screenFlags;
}


/* * * * Page Methods * * * */

void GameApp::flipPages( )
{
	HRESULT		ddrval;

	ddrval = this->IpDDSPrimary->Flip( NULL, DDFLIP_WAIT );
	if( ddrval != DD_OK )
	{
		RECT	frect;

		SetRect( &frect, 0, 0, this->screenWidth, this->screenHeight );

		ddrval = this->IpDDSPrimary->BltFast( 0, 0, this->IpDDSBack, &frect, DDBLTFAST_NOCOLORKEY | DDBLTFAST_WAIT );
		if( ddrval != DD_OK )
			this->ExitBool = TRUE;
	}
}

void GameApp::lockPage( short page )
{
	if( page == FrontPage )
		LockSurface( this->IpDDSPrimary , &this->pageBase, &this->pageBPR );

	if( page == BackPage )
		LockSurface( this->IpDDSBack , &this->pageBase, &this->pageBPR );
}

void GameApp::lockPage( short page, char **base, long *bytes_per_row )
{
	if( page == FrontPage )
		LockSurface( this->IpDDSPrimary , &this->pageBase, &this->pageBPR );

	if( page == BackPage )
		LockSurface( this->IpDDSBack , &this->pageBase, &this->pageBPR );

	*base			=	this->pageBase;
	*bytes_per_row	=	this->pageBPR;
}

void GameApp::unlockPage( short page )
{
	if( page == FrontPage )
		UnlockSurface( this->IpDDSPrimary );

	if( page == BackPage )
		UnlockSurface( this->IpDDSBack );
}

void GameApp::clearPage( short page )
{
	DDBLTFX		ddbltfx;

	ddbltfx.dwSize		=	sizeof( DDBLTFX );
	ddbltfx.dwFillColor =	0;

	if( page == FrontPage && IpDDSPrimary != NULL )
		this->IpDDSPrimary->Blt( NULL, NULL, NULL, DDBLT_COLORFILL | DDBLT_WAIT, &ddbltfx );

	if( page == BackPage && IpDDSBack != NULL )
		this->IpDDSBack->Blt( NULL, NULL, NULL, DDBLT_COLORFILL | DDBLT_WAIT, &ddbltfx );
}

/* * * * Blitter Methods * * * */

void GameApp::copyArea( short from_page, RECT *frect, short to_page, short x, short y )
{
	HRESULT		ddrval;

	ddrval = this->IpDDSPrimary->BltFast( x, y, this->IpDDSBack, frect, DDBLTFAST_NOCOLORKEY );
	if( ddrval != DD_OK )
	{
		this->ExitBool = TRUE;
	}
}


/* * * * Sync Methods * * * */
void GameApp::waitVBL( )
{
	IpDD->WaitForVerticalBlank( DDWAITVB_BLOCKEND, 0 );
}


/* * * * PixelBased Methods * * * */

void GameApp::putPixel8( short x, short y, char c )
{
	this->pageBase[ y * this->pageBPR + x ] = c;
}

char GameApp::getPixel8( short x, short y )
{
	return this->pageBase[ y * this->pageBPR + x ];
}


/* * * * Palette Methods * * * */

void GameApp::setRGBAtIndex( BYTE red, BYTE green, BYTE blue, BYTE index )
{
	this->MainPalette[ index ].peRed	=	red;
	this->MainPalette[ index ].peGreen	=	green;
	this->MainPalette[ index ].peBlue	=	blue;
}

void GameApp::getRGBAtIndex( BYTE *red, BYTE *green, BYTE *blue, BYTE index )
{
	*red	= this->MainPalette[ index ].peRed;
	*green	= this->MainPalette[ index ].peGreen;
	*blue	= this->MainPalette[ index ].peBlue;
}

void GameApp::updatePalette( void )
{
	IpDDPal->SetEntries( 0, 0, 256, MainPalette );
}



/* * * * Game Specific Methods * * * */

void GameApp::pause( void )
{
}

void GameApp::quit( void )
{
	this->ExitBool = true;
}


/* * * * Windows Specific Methods * * * */

void GameApp::setHInstance( HINSTANCE hinstance )
{
	this->hInstance = hinstance;
}

extern int FullScreen;

bool GameApp::systemTask( void )
{
	if( this->ExitBool == true )
		return false;
	
/*	while( PeekMessage( &msg, hwnd, 0, 0, (FullScreen ? PM_NOYIELD:0) | PM_NOREMOVE) )
	{
		if( msg.message == WM_QUIT )
		{
			this->ExitBool = true;
			return false;
		}

		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}*/

	while( PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ) )
	{
		if( GetMessage( &msg, NULL, 0, 0 ) )
		{
			if( msg.message == WM_QUIT )
			{
				this->ExitBool = true;
				return false;
			}

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

/*	if( PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ) )
	{
		if( ! GetMessage( &msg, NULL, 0, 0 ) )
		{
			this->ExitBool = true;
			return false;
		}
		// return msg.wParam;

		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}*/

	return true;
}
