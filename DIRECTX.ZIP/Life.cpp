/*
 * Lens.cpp - v1.0 - 1998/03/12
 *
 * Copyright (C) Johan Sorlin, spocke@algonet.se
 *
 *
 * 1.0 - 1998/03/12 - This file was created
 *
 */

/* ANSI Includes */
#include <Math.h>
#include <stdlib.h>

/* Local Includes */
#include "GameApp.hpp"

// Om en individ har 2 eller 3 grannar s� �verlever den
// Om individen har mindre �n 2 eller fler �n 3 s� d�r den
// Om en punkt inte har n�gon individ s� skapas en om det den har eXAkt 3 st grannar.

class CLife {
public:
	/* Constructor & DeConstructor */
	CLife( );
	~CLife( );
	
	/* Make & Dispose Methods */
	void make( short width, short height, long num_cells );
	void dispose( );
	
	/* Drawing Method */
	void draw( short pos_x, short pos_y );

private:
	short	Width;
	short	Height;
	char	*LifeData;
};


/* * * * Constructor & DeConstructor * * * */

CLife::CLife( )
{
	this->LifeData = NULL;
}

CLife::~CLife( )
{
	this->dispose( );
}


/* * * * Make & Dispose Methods * * * */

#define RND( min, max ) ( (rand( ) % ((max)-(min))) + (min) )

void CLife::make( short width, short height, long num_cells )
{
	this->Width  = width;
	this->Height = height;

	this->LifeData = (char *) malloc( (long) (width+10L) * (long) (height+10L) );
	if( this->LifeData == NULL )
	{
		/* Error */
		return;
	}

	for( short y=0; y<this->Height; y++ )
	for( short x=0; x<this->Width; x++ )
		this->LifeData[ y * this->Width + x ] = 0;

	for( ; num_cells >= 0L; num_cells-- )
	{
		this->LifeData[ RND( 0, height ) * width + RND( 0, width ) ] = (char) 1;
	}
}

void CLife::dispose( )
{
	if( this->LifeData != NULL )
	{
		free( (void *) this->LifeData );
		this->LifeData = NULL;
	}
}

	
/* * * * Drawing Method * * * */

void CLife::draw( short pos_x, short pos_y )
{
	short x, y, n;
	#define POINT( x, y ) this->LifeData[ (y) * this->Width + (x) ]

	pos_x = pos_y;

	if( this->LifeData == NULL )
		return;

	game.lockPage( FrontPage );

	/* ABC */
	/* D E */
	/* FGH */

	for( y=1; y<this->Height-1; y++ )
	for( x=1; x<this->Width-1; x++ )
	{
		n =  POINT( x-1, y-1 );
		n += POINT( x, y-1 );
		n += POINT( x+1, y-1 );

		n += POINT( x-1, y );
		n += POINT( x+1, y );

		n += POINT( x-1, y+1 );
		n += POINT( x,   y+1 );
		n += POINT( x+1, y+1 );

		if( n < 2 || n > 3 )
			this->LifeData[ y * this->Width + x ] = (char) 0;

		if( n == (char) 3 && (POINT( x, y ) == (char) 0) )
			this->LifeData[ y * this->Width + x ] = (char) 1;

		game.putPixel8( x, y, (BYTE) this->LifeData[ y * this->Width + x ] );
	}

	game.unlockPage( FrontPage );
}
