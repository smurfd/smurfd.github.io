/*
 * ZStars.cpp - 1998/04/06
 *
 * Copyright (C) 1998 Johan Sorlin, spocke@algonet.se
 *
 * This source contains a ZStar class, that makes stars
 * that comes towards the user. It's pretty easy to use
 * just setup a faded gray palette from 0-255.
 *
 * Note:
 *  This class requiers, GameShell.lib but you could
 *  change it to fit your own lib aswell.
 *
 * History:
 *  1.0 - 1998/04/23 - The first version.
 *
 */

/* ANSI-C Includes */
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>

/* Local includes */
#include "GameApp.hpp"


/* * * * Class Definition * * * */

class ZStars {
public:
	/* Constructor & DeConstructor */
	ZStars( );
	~ZStars( );

	/* Making/Disposing Methods */
	void makeStars( RECT in_rect, short num_stars, short warp, short max_speed );
	void dispose( );

	/* Drawing Methods */
	void drawStars( short ang );

private:
	/* Private Methods */
	void moveBackStar( short star_num );
	short rnd( short min, short max );

	/* ZStars Main Data */
	short	*Stars_X;
	short	*Stars_Y;
	short	*Stars_Z;
	short	*Stars_Speed;
	short	*Stars_OldX;
	short	*Stars_OldY;

	RECT	MainRect;
	short	NumberOfStars;
	short	WarpFactor;
	short	MaxSpeed;

	short	MiddleX;
	short	MiddleY;
};


/* * * * Constructor & DeConstructor * * * */

ZStars::ZStars( )
{
	/* Initialize ZStars Main Data */
	this->Stars_X		=	NULL;
	this->Stars_Y		=	NULL;
	this->Stars_Z		=	NULL;
	this->Stars_Speed	=	NULL;
	this->Stars_OldX	=	NULL;
	this->Stars_OldY	=	NULL;

	SetRect( &this->MainRect, 0, 0, 0, 0 );
	this->NumberOfStars	=	0;
	this->WarpFactor	=	0;
	this->MaxSpeed		=	0;

	this->MiddleX		=	0;
	this->MiddleY		=	0;
}

ZStars::~ZStars( )
{
	this->dispose( );
}


/* * * * Initializing Methods * * * */

void ZStars::makeStars( RECT in_rect, short num_stars, short warp, short max_speed )
{
	/* If allready allocated, then dispose */
	this->dispose( );

	/* Allocate Space for StarsX */
	this->Stars_X = (short *) malloc( (long) num_stars * sizeof( short ) );
	if( this->Stars_X == NULL )
	{
		this->dispose( );
		return;
	}

	/* Allocate Space for StarsY */
	this->Stars_Y = (short *) malloc( (long) num_stars * sizeof( short ) );
	if( this->Stars_Y == NULL )
	{
		this->dispose( );
		return;
	}

	/* Allocate Space for StarsZ */
	this->Stars_Z = (short *) malloc( (long) num_stars * sizeof( short ) );
	if( this->Stars_Z == NULL )
	{
		this->dispose( );
		return;
	}

	/* If diffrent speed, allocate speed array */
	if( max_speed > 1 )
	{
		this->Stars_Speed = (short *) malloc( (long) num_stars * sizeof( short ) );
		if( this->Stars_Speed == NULL )
		{
			this->dispose( );
			return;
		}
	}

	/* Allocate Space for StarsOldX */
	this->Stars_OldX = (short *) malloc( (long) num_stars * sizeof( short ) );
	if( this->Stars_OldX == NULL )
	{
		this->dispose( );
		return;
	}

	/* Allocate Space for StarsOldY */
	this->Stars_OldY = (short *) malloc( (long) num_stars * sizeof( short ) );
	if( this->Stars_OldY == NULL )
	{
		this->dispose( );
		return;
	}

	/* Set other data member */
	this->MainRect			=	in_rect;
	this->NumberOfStars		=	num_stars;
	this->WarpFactor		=	warp;
	this->MaxSpeed			=	max_speed;
	
	this->MiddleX = (this->MainRect.right - this->MainRect.left) / 2;
	this->MiddleY = (this->MainRect.bottom - this->MainRect.top) / 2;

	/* Set the stars at random pos X,Y,Z */
	for( int i=0; i<this->NumberOfStars; i++ )
	{
		Stars_X[ i ]	=	rnd( -this->MiddleX, this->MiddleX );
		Stars_Y[ i ]	=	rnd( -this->MiddleY, this->MiddleY );
		Stars_Z[ i ]	=	rnd( 2,255 );

		Stars_OldX[ i ]	= 0;
		Stars_OldY[ i ]	= 0;

		if( this->MaxSpeed > 1 )
			Stars_Speed[ i ]	=	rnd( 1, this->MaxSpeed );
	}
}

void ZStars::dispose( )
{
	/* If allocated Stars_X */
	if( this->Stars_X != NULL )
	{
		free( (void *) this->Stars_X );
		this->Stars_X = NULL;
	}

	/* If allocated Stars_Y */
	if( this->Stars_Y != NULL )
	{
		free( (void *) this->Stars_Y );
		this->Stars_Y = NULL;
	}

	/* If allocated Stars_Z */
	if( this->Stars_Z != NULL )
	{
		free( (void *) this->Stars_Z );
		this->Stars_Z = NULL;
	}

	/* If allocated Stars_Speed */
	if( this->Stars_Speed != NULL )
	{
		free( (void *) this->Stars_Speed );
		this->Stars_Speed = NULL;
	}

	/* If allocated Stars_OldX */
	if( this->Stars_OldX != NULL )
	{
		free( (void *) this->Stars_OldX );
		this->Stars_OldX = NULL;
	}

	/* If allocated Stars_OldY */
	if( this->Stars_OldY != NULL )
	{
		free( (void *) this->Stars_OldY );
		this->Stars_OldY = NULL;
	}
}


/* * * * Drawing Methods * * * */

static short ang2 = 0;

void ZStars::drawStars( short ang )
{
	short	nx, ny;	/* NewScreenX, NewScreenY */
	short	rx, ry;
	char	*base;
	long	rowBytes;
	#define FPLOT( x,y,c ) base[ (y)*rowBytes+(x) ] = (c)

	/* Lock page */
//	game.lockPage( BackPage, (char **) &base, &rowBytes );
	game.lockPage( FrontPage );

	ang2+=2;

	for( short i=0; i<this->NumberOfStars; i++ )
	{
		/* If star is in your face */
		if( Stars_Z[ i ] > 0 )
		{
			/* Calc Rotated Star Pos */
			rx = Stars_X[ i ];
			ry = Stars_Y[ i ];

//			rx = (short) ((float)Stars_X[ i ] * cos( ang2 * 0.001745f ) - (float)Stars_Y[ i ] * sin( ang2 * 0.001745f ));
//			ry = (short) ((float)Stars_X[ i ] * sin( ang2 * 0.001745f ) + (float)Stars_Y[ i ] * cos( ang2 * 0.001745f ));

			/* Convert X,Y,Z to screen X,Y */
			nx	=	( ( rx << 7 ) / Stars_Z[ i ] ) + this->MiddleX;
			ny	=	( ( ry << 7 ) / Stars_Z[ i ] ) + this->MiddleY;

			/* Offset screen cords */
			nx  +=	(short) this->MainRect.left;
			ny  +=	(short) this->MainRect.top;

			/* Check if it's within bounds */
			if( (nx > this->MainRect.left && nx < this->MainRect.right) &&
				(ny > this->MainRect.top && ny < this->MainRect.bottom) )
			{
				game.putPixel8( Stars_OldX[ i ], Stars_OldY[ i ],(char) 0 );
				game.putPixel8( nx, ny,(char) 255-Stars_Z[ i ] );

				Stars_OldX[ i ] = nx;
				Stars_OldY[ i ] = ny;

				if( this->MaxSpeed > 1 )
					Stars_Z[ i ] -= Stars_Speed[ i ];
				else
					Stars_Z[ i ] -= this->WarpFactor;
			}
			else
				this->moveBackStar( i );
		}
		else
			this->moveBackStar( i );
	}

	/* Unlock page */
	game.unlockPage( FrontPage );
}


/* * * * Private Methods * * * */

void ZStars::moveBackStar( short star_num )
{
	/* Move star back */
//	Stars_X[ star_num ]	=	rnd( -this->MiddleX, this->MiddleX );
//	Stars_Y[ star_num ]	=	rnd( -this->MiddleY, this->MiddleY );
	Stars_Z[ star_num ]	= 255;

	/* Change Velocity */
	if( this->MaxSpeed > 1 )
		Stars_Speed[ star_num ]	=	rnd( 1, this->MaxSpeed );
}

short ZStars::rnd( short min, short max )
{
	return( (rand( ) % (max-min)) + min );
}
