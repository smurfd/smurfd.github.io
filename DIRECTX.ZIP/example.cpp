/*
 * Example.cpp - 1998/03/04
 *
 * Copyright (C) 1998 Johan Sorlin, spocke@algonet.se
 *
 * This program shows how to setup and make a fullscreen
 * graphical application under Win32. It uses DirectX for
 * fast blittings and mode switching.
 *
 * No Updates
 *
 */

/* Windows Specific Includes */
#include <ddraw.h>
#include <windows.h>
#include <windowsx.h>

/* ANSI-C Includes */
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>

/* Local includes */
#include "GameApp.hpp"
#include "ZStars.hpp"



/* WndProc, this event handler must be defined in eatch app */

int FullScreen = TRUE;
int ExitBool = FALSE;
short mouseX, mouseY;
short co = 0;

LRESULT CALLBACK WndProc( HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
	switch( iMsg )
	{
		case WM_SYSKEYDOWN:
		case WM_SYSKEYUP:
		case WM_SYSCHAR:
			game.quit( );
			PostMessage( hwnd, WM_CLOSE, 0, 0 );

			if( FullScreen == TRUE )
				return(0);
		break;

		case WM_KEYDOWN:
			switch (wParam)
			{
				case VK_ESCAPE:								//Exit on ESC or F12 keys
				case VK_F12:
					PostMessage( hwnd, WM_CLOSE, 0, 0 );
					game.closeScreen( );
					exit( 1 );
					return 0;
			}
			return 0;
		break;

		case WM_TIMER:
		case WM_SYSCOMMAND:
			game.clearPage( FrontPage );

			switch( wParam & 0xFFF0 )
			{
				case SC_SCREENSAVE:     //disable Screen Saver
				case SC_MONITORPOWER:   //disable Monitor Power Down
				return 0;
			}
		break;

		case WM_LBUTTONUP:
		case WM_RBUTTONUP:
//			game.quit( );
//			PostMessage( hwnd, WM_CLOSE, 0, 0 );
			ExitBool = TRUE;
			return 0;
			break;

//		case WM_CREATE:
//			break;

		case WM_ACTIVATEAPP:
			FullScreen = wParam;
			InvalidateRect (hwnd, NULL, TRUE);
			// return 0;
			break;

//		case WM_DESTROY:
//			PostQuitMessage( 0 );
//			return 0;
//		break;

		case WM_MOUSEMOVE:
			{
				POINTS mousePos;

				mousePos = MAKEPOINTS( lParam );
				mouseX = (short) mousePos.x;
				mouseY = (short) mousePos.y;
			}
			break;

		case WM_PAINT:
			game.clearPage( FrontPage );
			break;
	}

	return DefWindowProc( hwnd, iMsg, wParam, lParam );
}

extern void UpdateFire( RECT *in_r, short sub_num );

class ShadeBob {
public:
	/* Constructor & DeConstructor */
	ShadeBob( );
	~ShadeBob( );

	/* Making/UnMaking Methods */
	void make( short diameter );
	void dispose( );

	/* Drawing Methods */
	void draw( short off_x, short off_y );

private:
	/* ShadeBob MainData */
	short		Diameter;
	short		Radius;
	BYTE 		*BobData;

	/* Private Methods */
	void bobCircle( short x_center, short y_center, short radius, BYTE c );
};

class HStars {
public:
	/* Constructor & DeConstructor */
	HStars( );
	~HStars( );

	/* Making/Disposing Methods */
	void makeStars( RECT in_rect, short num_stars, short warp, short max_speed );
	void dispose( );

	/* Drawing Methods */
	void drawStars( );

private:
	/* Private Methods */
	int rnd( int min, int max );

	/* ZStars Main Data */
	WORD	*Stars_X;
	WORD	*Stars_Y;
	BYTE	*Stars_C;
	WORD	*Stars_Speed;

	RECT	MainRect;
	short	NumberOfStars;
	short	WarpFactor;
	short	MaxSpeed;

	short	MiddleX;
	short	MiddleY;
};

class CLife {
public:
	/* Constructor & DeConstructor */
	CLife( );
	~CLife( );
	
	/* Make & Dispose Methods */
	void make( short width, short height, long num_cells );
	void dispose( );
	
	/* Drawing Method */
	void draw( short pos_x, short pos_y );

private:
	short	width;
	short	height;
};

extern void	SPlasma( short page, RECT *rect, BYTE ec );
extern void MakeBlur( RECT *in_r );

void HStarsEffect( )
{
	HStars		zstars;
	RECT		rect;
	int			i;

	game.clearPage( FrontPage );
	ExitBool = FALSE;

	/* Set palette to a gray blend */
	for( i=0; i<256; i++ )
		game.setRGBAtIndex( (BYTE) i, (BYTE) i, (BYTE) i, (BYTE) i );

	game.updatePalette( );

//	game.clearPage( FrontPage );
//	game.clearPage( BackPage );

	SetRect( &rect, 0, 0, 640, 480 );
	zstars.makeStars( rect, 10000, 1, 8 );

	co = 0;
	while( (game.systemTask( ) && !ExitBool) /*&& co++ < 1000*/ )
	{
		if( FullScreen )
		{
			//game.flipPages( );
			zstars.drawStars( );
			//game.copyArea( BackPage, &rect, FrontPage, (short) rect.left, (short) rect.top );
		}
	}
}

void ZStarsEffect( )
{
	ZStars		zstars;
	RECT		rect;
	int			i;

	game.clearPage( FrontPage );
	ExitBool = FALSE;

	/* Set palette to a gray blend */
	for( i=0; i<256; i++ )
		game.setRGBAtIndex( (BYTE) i, (BYTE) i, (BYTE) i, (BYTE) i );

	game.updatePalette( );

//	game.clearPage( FrontPage );
//	game.clearPage( BackPage );

	SetRect( &rect, 0, 0, 640, 480 );
	zstars.makeStars( rect, 10000, 1, 1 );

	co = 0;
	while( (game.systemTask( ) && !ExitBool) /*&& co++ < 1000*/ )
	{
		if( FullScreen )
		{
			//game.flipPages( );
			zstars.drawStars( 0 );
			//game.copyArea( BackPage, &rect, FrontPage, (short) rect.left, (short) rect.top );
		}
	}
}


void ShBobsEffect( void )
{
	ShadeBob	sbob;
	int			i;

	game.clearPage( FrontPage );
	ExitBool = FALSE;

	for( i=0; i<255; i++ )
		game.setRGBAtIndex( (BYTE) i, (BYTE) 0, (BYTE) i, (BYTE) i );

//	for( i=128; i<256; i++ )
//		game.setRGBAtIndex( (BYTE) (255-i), (BYTE) 0, (BYTE) (255-i), (BYTE) i );

	game.updatePalette( );

	sbob.make( 64 );

	co = 0;
	while( (game.systemTask( ) && !ExitBool) /*&& co++ < 1000*/ )
	{
		if( FullScreen )
		{
			// sbob.draw( rand( ) % (640-64), rand( ) % (480-64) );
			sbob.draw( mouseX, mouseY );
		}
//		sbob.draw( mouseX, mouseY );
	}
}

short rnd( short min, short max )
{
	return( (rand( ) % (max-min)) + min );
}

class Stars3D {
public:
	/* Constructor & DeConstructor */
	Stars3D( );
	~Stars3D( );

	/* Making/Disposing Methods */
	void make( short num_stars, short max_distance );
	void dispose( );

	/* Drawing Methods */
	void rotate( short angle_x, short angle_y, short angle_z );
	void draw( short off_x, short off_y, short off_z );

private:
	/* Private Methods */
	int rnd( int min, int max );

	/* Stars3D Main Data */
	struct Pixel3D {
		short	x;
		short	y;
		short	z;
		short	c;

		short	old_x;
		short	old_y;
	} *Stars;

	short	Angle_X;
	short	Angle_Y;
	short	Angle_Z;
	short	Num_Stars;

	double	*sin_tab;
	double	*cos_tab;
};

void FireWorksEffect( )
{
	Stars3D stars;
	short	i, off_z, ang_z;

	game.clearPage( FrontPage );
	ExitBool = FALSE;

	for( i=0; i<255; i++ )
		game.setRGBAtIndex( (BYTE) i, (BYTE) i, (BYTE) i, (BYTE) i );

	game.updatePalette( );

	stars.make( 1000, 100 );

	off_z = 200;
	ang_z = 0;

	co = 0;
	while( (game.systemTask( ) && !ExitBool) /*&& co++ < 1000*/ )
	{
		if( FullScreen )
		{
/*			if( off_z > 500 )
				off_z = 200;
			else
				off_z++;
*/

			if( ang_z > 359 * 10 )
				ang_z = 0;
			else
				ang_z++;

			stars.rotate( mouseY, mouseX, ang_z / 10 );
			stars.draw( mouseX, mouseY, off_z );
		}
//		sbob.draw( mouseX, mouseY );
	}
}

void FireWorksEffect2( )
{
	int		i, x[ 100 ], y[ 100 ], x_add[ 100 ], y_add[ 100 ];

	game.clearPage( FrontPage );
	ExitBool = FALSE;

	for( i=0; i<100; i++ )
	{
		x[ i ]		= (int) (sin( (float) (i*(360.0f / 100.0f)) * 0.01745f ) * 100);//rnd( -200, 200 );
		y[ i ]		= (int) (cos( (float) (i*(360.0f / 100.0f)) * 0.01745f ) * 100);//rnd( -200, 200 );
		x_add[ i ]	= rnd( -10, 10 );
		y_add[ i ]	= rnd( -10, 10 );

		if( x_add[ i ] == 0 )
			x_add[ i ] = 1;

		if( y_add[ i ] == 0 )
			y_add[ i ] = 1;
	}

	/* Set palette to a gray blend */
	for( i=0; i<256; i++ )
		game.setRGBAtIndex( (BYTE) i, (BYTE) i, (BYTE) i, (BYTE) i );

	game.updatePalette( );

	co = 0;
	while( (game.systemTask( ) && !ExitBool) )
	{
		if( FullScreen )
		{
			game.lockPage( FrontPage );
			game.waitVBL( );

			for( i=0; i<100; i++ )
			{
				game.putPixel8( 320 + (x[ i ]), 240 + y[ i ], 0 );

				x[ i ] = 1;

				if( x[ i ] < 1 )   x[ i ] = 639;
				if( x[ i ] > 639 ) x[ i ] = 1;

//				y[ i ]++;

				game.putPixel8( 320 + (x[ i ]), 240 + y[ i ], 255 );
			}

			game.unlockPage( FrontPage );
		}
	}
}

class PTunnel {
public:
	/* Constructor & DeConstucutor */
	PTunnel( );
	~PTunnel( );

	/* */
	void make( RECT in_rect, short num_rings, short diameter );
	void draw( short pos_x, short pos_y );
	void dispose( );

private:
	RECT	MainRect;
	short	NumberOfRings;
	short	RingDiameter;

	struct Ring {
		short Pixel_X[36];
		short Pixel_Y[36];
	} *Rings;
};

void PTunnelEffect( void )
{
	PTunnel		tunnel;
	int			i;
	RECT		r;

	game.clearPage( FrontPage );
	ExitBool = FALSE;

	for( i=0; i<255; i++ )
		game.setRGBAtIndex( (BYTE) i, (BYTE) i, (BYTE) i, (BYTE) i );

//	for( i=128; i<256; i++ )
//		game.setRGBAtIndex( (BYTE) (255-i), (BYTE) 0, (BYTE) (255-i), (BYTE) i );

	game.updatePalette( );

	SetRect( &r, 0, 0, 639, 479 );
	tunnel.make( r, 100, 100 );

	co = 0;
	while( (game.systemTask( ) && !ExitBool) /*&& co++ < 1000*/ )
	{
		if( FullScreen )
		{
			tunnel.draw( mouseX, mouseY );
		}
//		sbob.draw( mouseX, mouseY );
	}
}

void DotsEffect( )
{
	int		i;
	float	Dot_X[ 1000 ], Dot_Y[ 1000 ];
	float	Dot_XAdd[ 1000 ], Dot_YAdd[ 1000 ];
	byte	Dot_Color[ 1000 ];

	game.clearPage( FrontPage );
	ExitBool = FALSE;

	for( i=0; i<255; i++ )
		game.setRGBAtIndex( (BYTE) i, (BYTE) i, (BYTE) i, (BYTE) i );

	game.updatePalette( );

	for( i=0; i<1000; i++ )
	{
		Dot_X[ i ]     = rnd( 315, 325 );//(float) (rand( ) % 640);
		Dot_Y[ i ]     = rnd( 235, 245 );//(float) (rand( ) % 400);
		Dot_XAdd[ i ]  = rnd( -20, 20 ) / 20.0f;
		Dot_YAdd[ i ]  = rnd( -20, 20 ) / 20.0f;
		Dot_Color[ i ] = rnd( 100, 255 );
	}

	co = 0;
	while( (game.systemTask( ) && !ExitBool) /*&& co++ < 1500*/ )
	{
		if( FullScreen )
		{
			game.waitVBL( );
			game.lockPage( FrontPage );

			for( i=0; i<1000; i++ )
			{
				game.putPixel8( (short) Dot_X[ i ], (short) Dot_Y[ i ], 0 );

				Dot_X[ i ] += Dot_XAdd[ i ];
				Dot_Y[ i ] += Dot_YAdd[ i ];

				if( Dot_X[ i ] < 1.0f || Dot_X[ i ] > 639.0f )
				{
					Dot_XAdd[ i ] *= -1.0f;
					Dot_X[ i ] += Dot_XAdd[ i ];
				}

				if( Dot_Y[ i ] < 1.0f || Dot_Y[ i ] > 479.0f )
				{
					Dot_YAdd[ i ] *= -1.0f;
					Dot_Y[ i ] += Dot_YAdd[ i ];
				}

				game.putPixel8( (short) Dot_X[ i ], (short) Dot_Y[ i ], Dot_Color[ i ] );
			}

			game.unlockPage( FrontPage );
		}
//		sbob.draw( mouseX, mouseY );
	}
}

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow )
{
	short			i;
	RECT			rect;
	
	RECT			r;

	/* Set hInstance and open screen */
	game.setHInstance( hInstance );
	game.openScreen( 640, 480, 8, 0 );
	ShowCursor( FALSE );

	SetRect( &rect, 0, 0, 640, 480 );

//	sbob.make( 64 );

//	SetRect( &r, 0, 0, 639, 479 );
//	SPlasma( BackPage, &r, 100 );

	while( 1 )
	{
		FireWorksEffect( );
		ZStarsEffect( );
		HStarsEffect( );
		ShBobsEffect( );
		PTunnelEffect( );
		DotsEffect( );
	}

	game.closeScreen( );
	return 0;

//	life.make( 100, 100, 10000L );

//	for( i=0; i<128; i++ )
//		game.setRGBAtIndex( (BYTE) i, (BYTE) 0, (BYTE) i, (BYTE) i );

//	for( i=128; i<256; i++ )
//		game.setRGBAtIndex( (BYTE) (255-i), (BYTE) 0, (BYTE) (255-i), (BYTE) i );

//	game.setRGBAtIndex( (BYTE) 255, (BYTE) 255, (BYTE) 255, (BYTE) 1 );

	game.updatePalette( );

	SPlasma( BackPage, &r, 255 );

//	ShowCursor( TRUE );

	/* Main Loop */
	while( game.systemTask( ) )
	{
		if( FullScreen )
		{
//			game.waitVBL( );
//			life.draw( 0, 0 );
//			UpdateFire( &r, 3 );
//			game.flipPages( );

//			game.copyArea( BackPage, &r, FrontPage, (short) r.left, (short) r.top );
//			MakeBlur( &r );

/*			game.lockPage( FrontPage );

			for( i=0; i<256; i++ )
				game.putPixel8( i, 0, (char) i );

			game.unlockPage( FrontPage );
*/

//			sbob.draw( mouseX, mouseY );
		}
	}

	game.closeScreen( );
	return 0;
}
