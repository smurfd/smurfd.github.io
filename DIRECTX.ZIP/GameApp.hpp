/*
 * GameApp.hpp - 1998/03/03
 *
 * Copyright (C) 1998 Johan Sorlin, spocke@algonet.se
 *
 *
 * No Updates
 *
 */

#ifndef GAMEAPP_HPP
#define GAMEAPP_HPP

/* * * * Windows Specific Includes * * * */
#include <ddraw.h>
#include <windows.h>
#include <windowsx.h>

/* * * * User defined extern Function Prototypes * * * * */
extern LRESULT CALLBACK WndProc( HWND, UINT, WPARAM, LPARAM );

/* * * * GameApp Constants * * * */

const short FrontPage = 1;
const short BackPage  = 2;

/* * * * GameApp Class Definition * * * */

class GameApp {
public:
	/* Constructor & DeConstrucor */
	GameApp( );
	~GameApp( );

	/* Screen Specific Methods */
	void openScreen( short width, short height, short depth, short flags );
	void closeScreen( );

	/* Accessor Methods */
	short getWidth( );
	short getHeight( );
	short getDepth( );
	short getFlags( );

	/* Page Methods */
	void flipPages( );
	void lockPage( short page );
	void lockPage( short page, char **base, long *bytes_per_row );
	void unlockPage( short page );
	void clearPage( short page );

	/* Blitter Methods */
	void copyArea( short from_page, RECT *frect, short to_page, short x, short y );

	/* Sync Methods */
	void waitVBL( );

	/* PutPixel Methods */
	void  putPixel8( short x, short y, char c );
	void  putPixel16( short x, short y, short c );
	void  putPixel32( short x, short y, long c );

	/* GetPixel Methods */
	char  getPixel8( short x, short y );
	short getPixel16( short x, short y );
	long  getPixel32( short x, short y );

	/* Palette Methods */
	void setRGBAtIndex( BYTE red, BYTE green, BYTE blue, BYTE index );
	void getRGBAtIndex( BYTE *red, BYTE *green, BYTE *blue, BYTE index );
	void updatePalette( );

	/* Game Specific Methods */
	void pause( void );
	void quit( void );

	/* Windows Specific Methods */
	void setHInstance( HINSTANCE hinstance );
	bool systemTask( void );

private:
	/* GameApp Main Data */
	short		screenWidth;
	short		screenHeight;
	short		screenDepth;
	short		screenFlags;
	bool		ExitBool;

	/* Active Page Data */
	char		*pageBase;
	long		pageBPR;

	/* DirectDraw Data */
	LPDIRECTDRAW			IpDD;
	LPDIRECTDRAWSURFACE		IpDDSPrimary;
	LPDIRECTDRAWSURFACE		IpDDSBack;

	/* Main Window Data */
	WNDCLASSEX				wndclass;
	MSG						msg;
	HWND					hwnd;
	HINSTANCE				hInstance;
	char					szAppName[32];

	/* Main Palette Data */
	PALETTEENTRY			MainPalette[ 256 ];
};

/* * * * The Main Object * * * */

extern GameApp		game;

#endif
