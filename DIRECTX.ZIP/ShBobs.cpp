/*
 * ShBobs.cpp - v1.0 - 1998/03/12
 *
 * Copyright (C) Johan Sorlin, spocke@algonet.se
 *
 *
 * 1.0 - 1998/03/12 - This file was created
 *
 */

/* ANSI Includes */
#include <math.h>

/* Local Includes */
#include "GameApp.hpp"

/* Windows typedef */
#define BYTE unsigned char


/* * * * Class Definition * * * */

class ShadeBob {
public:
	/* Constructor & DeConstructor */
	ShadeBob( );
	~ShadeBob( );

	/* Making/UnMaking Methods */
	void make( short diameter );
	void dispose( );

	/* Drawing Methods */
	void draw( short off_x, short off_y );

private:
	/* ShadeBob MainData */
	short		Diameter;
	short		Radius;
	BYTE 		*BobData;

	/* Private Methods */
	void bobCircle( short x_center, short y_center, short radius, BYTE c );
};


/* * * * Constructor & DeConstructor * * * */

ShadeBob::ShadeBob( )
{
	/* Initialize ShadeBob MainData */
	this->Diameter	=	0;
	this->Radius	=	0;
	this->BobData	=	NULL;
}

ShadeBob::~ShadeBob( )
{
	/* Dispose on DeConstruct */
	this->dispose( );
}


/* * * * Making/UnMaking Methods * * * */

void ShadeBob::make( short diameter )
{
	short	i;

	/* Dispose old BobData */
	if( this->BobData != NULL )
		this->dispose( );

	/* Allocate BobData */
	this->BobData = (BYTE *) malloc( (long) ( sizeof( short ) * ((diameter+20L) * (diameter+20L)) ) );
	if( this->BobData == NULL )
	{
		/* Error */
		this->dispose( );
		return;
	}

	/* Set Diameter and Radius */
	this->Diameter	=	diameter;
	this->Radius	=	diameter / 2;

	for( short y=0; y<diameter; y++ )
	for( short x=0; x<diameter; x++ )
		this->BobData[ x+diameter*y ] = 0;

	/* Make the BobData */
	for( i=0; i<this->Radius; i++ )
		this->bobCircle( this->Radius, this->Radius, (this->Radius) - i, (char) i );
}

void ShadeBob::dispose( )
{
	/* If allocated, DeAllocate */
	if( this->BobData == NULL )
	{
		free( (void *) this->BobData );
		this->BobData = NULL;
	}

	/* Reset Diameter and Radius */
	this->Diameter	=	0;
	this->Radius	=	0;
}


/* * * * Drawing Methods * * * */

void ShadeBob::draw( short off_x, short off_y )
{
	short 	x, y, co;
	char	*base;
	unsigned short color;
	long	bytes_per_row;
	#define FPLOT( x, y, c )	base[ (y)*bytes_per_row+(x) ] = (c)
	#define FPOINT( x, y )		base[ (y)*bytes_per_row+(x) ]

	/* NULL Check BobData */
	if( this->BobData == NULL )
		return;

	/* Make sure that the Bob is in side Screen bounds */
	if( off_y > (game.getHeight( )-1)-this->Diameter )
		off_y = (game.getHeight( )-2) - this->Diameter;

	if( off_x > (game.getWidth( )-1)-this->Diameter )
		off_x = (game.getWidth( )-2) - this->Diameter;

	/* Set co counter */
	co = -1;

	/* Lock FrontPage */
	game.lockPage( FrontPage, &base, &bytes_per_row );
	game.waitVBL( );

	/* Add BobData to Screen Data */
	for( y=0; y<this->Diameter; y++ )
	for( x=0; x<this->Diameter; x++ )
	{
		co++;

		color = FPOINT( x + off_x, y + off_y ) + this->BobData[ co ];
		if( color > 250 ) color = 128;

		if( (this->BobData[ co ] != (char) 0) )
			FPLOT( x + off_x, y + off_y, (char) color );
	}

	/* UnLock FrontPage */
	game.unlockPage( FrontPage );
}


/* * * * Private Methods * * * */

void ShadeBob::bobCircle( short x_center, short y_center, short radius, BYTE c )
{
	short 	x, y, d, i;

	/* NULL Check BobData */
	if( this->BobData == NULL )
		return;

	/* Set the variabels */
  	x	=	0;
 	y	=	radius;
  	d	=	2 * (1-radius);

  	while( y >= 0 )
  	{
  		/* Draw the two Horizontal Lines */
  		for( i=x_center-x; i<=x_center+x; i++ )
  			this->BobData[ (y_center+y)*this->Diameter+i ] = c;

   		for( i=x_center-x; i<=x_center+x; i++ )
   			this->BobData[ (y_center-y)*this->Diameter+i ] = c;
 
 		/* Calculate Beizer Circle */
    	if( d + y > 0 )
    	{
     		y -= 1;
     		d -= (2*y+1);
    	}

    	if( x > d )
   		{
      		x += 1;
      		d += (2*x+1);
    	}
    }
}
