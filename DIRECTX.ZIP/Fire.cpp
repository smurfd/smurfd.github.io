/*
 * Fire.cpp - v1.0 - 1998/03/12
 *
 * Copyright (C) Johan Sorlin, spocke@algonet.se
 *
 * This file contains a functions that makes
 * a pretty neat fire effect. To use it just setup a fire
 * like palette.
 *
 * 1.0 - 1998/03/12 - This file was created
 *
 */

/* ANSI Includes */
#include <stdlib.h>				/* For rand( ) */

/* Local Includes */
#include "GameApp.hpp"


/* * * * Fire Function * * * */

void UpdateFire( RECT *in_r, short sub_num )
{
	short	x, y, x1, y1, x2, y2;
	short	col;
	BYTE	*base;
	BYTE	*baseA, *baseB, *baseC, *baseD, *baseE;
	long	bytes_per_row, yoffset;

	/* Lock FrontPage, and get screen base and BPR */
	game.lockPage( FrontPage, (char **) &base, &bytes_per_row );

	x1 = (short) in_r->left;
	y1 = (short) in_r->top;
	x2 = (short) in_r->right;
	y2 = (short) in_r->bottom;

	/*  A  */
	/*  B  */
	/* CDE */

	/* Setup Base Pointers */
	baseA = base + 1;
	baseB = base + bytes_per_row + 1;
	baseC = base + bytes_per_row*2 + 0;
	baseD = base + bytes_per_row*2 + 1;
	baseE = base + bytes_per_row*2 + 2;

	/* Make two bottom rows random 100 - 254 */
	for( x=x1; x<x2; x++ )
	{
		/* Get random color value */
		col = (BYTE) (rand( ) % 154) + 100;

		/* Plot color value at bottom rows */
		*(base + x + bytes_per_row * (y2-1)) = (BYTE) col;
		*(base + x + bytes_per_row * (y2-2)) = (BYTE) col;
	}

	/* Make/Draw Fire Effect */
	for( y=y1; y<y2-2; y++ )
	{
		/* Calculate yoffset */
		yoffset = (long) y * (long) bytes_per_row;

		/* Loop from (x1) to (x2-1) */
		for( x=x1; x<x2-1; x++ )
		{
			/* Get avarage pixel value col = A+B+C+D+E / 4 */
			col = (*(baseB + x + yoffset) + *(baseC + x + yoffset)
				+ *(baseD + x + yoffset) + *(baseE + x + yoffset)) >> 2;

			/* Subtract, to make fire fade faster */
			col -= sub_num;
			
			/* Skip color index 0 and below */
			if( col < 1 )
				col = 1;

			/* Plot Pixel */
			*(baseA+x+yoffset) = (BYTE) col;
		}
	}

	/* UnLock FrontPage */
	game.unlockPage( FrontPage );
}
