/*
 * Lens.hpp - v1.0 - 1998/03/04
 *
 * Copyright (C) Johan Sorlin, spocke@algonet.se
 *
 *
 * 1.0 - 1998/03/04 - This file was created
 *
 */

#ifndef LENS_HPP
#define LENS_HPP

/* * * * Class Definition * * * */

class Lens {
public:
	/* Constructor & DeConstrustor */
	Lens( );
	~Lens( );
	
	/* Make and Dispose */
	void make( short diameter, short mfactor );
	void dispose( );
	
	/* Drawing Mehtods */
	void draw( short off_x, short off_y );

private:
	char	*oData;
	char	*tfm;
	short	diameter;
	
	short	old_posX;
	short	old_posY;
};

#endif
