/*
 * SPlasma.cpp - v1.0 - 1998/03/12
 *
 * Copyright (C) Johan Sorlin, spocke@algonet.se
 *
 *
 * 1.0 - 1998/03/12 - This file was created
 *
 */

/* Local Includes */
#include "GameApp.hpp"

/* Windows typedef */
#define BYTE unsigned char

/* Function ProtoType */
extern void	SPlasma( short page, RECT *rect, BYTE ec );


/* * * * Functions * * * */

void SPlasma( short page, RECT *rect, BYTE max_color )
{
	short				x,y;
	BYTE				color = 0;
	const short			HalfWidth  = (rect->right - rect->left) / 2;
	const short			HalfHeight = (rect->bottom - rect->top) / 2;

	game.lockPage( page );

	for( y =-HalfHeight; y<HalfHeight; y++ )
	for( x =-HalfWidth;  x<HalfWidth;  x++ )
	{
//			c = ( ((x*x)*4)+((y*y)*2) ) / 100;
//			c = (x*y/16)/16;
//			c = ((x & y) * (x | y)) / 20;
//			c = (x | y);
//			c = (( x * y ) + ( x | y ) * ( x ^ y ))/20;
//			c = g*y;
//			c = (x * x) + (y * y);
//			c = x ^ rnd( 1,5 ) + y * g;
//			color = g*x/2000-y;
//			color = (x*y*16)/16;
//			color = (y*x/16)/160;
//			c = (x*y) / 250;
			color = x*y+x/25;
//			c = (x+y)/10;
//			c = (x * c) % y;
//			color = y * g / (x+1000);

			if( color > max_color )
				color = color % max_color;

			game.putPixel8( (x + HalfWidth) + (short) rect->left, (y + HalfHeight) + (short) rect->top, color );
	}

	game.unlockPage( page );
}
