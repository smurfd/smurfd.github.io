/*
*
*
*
*/

/* ANSI-C Includes */
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>

/* Local includes */
#include "GameApp.hpp"


/* * * * Class Definition * * * */

class HStars {
public:
	/* Constructor & DeConstructor */
	HStars( );
	~HStars( );

	/* Making/Disposing Methods */
	void makeStars( RECT in_rect, short num_stars, short warp, short max_speed );
	void dispose( );

	/* Drawing Methods */
	void drawStars( );

private:
	/* Private Methods */
	int rnd( int min, int max );

	/* ZStars Main Data */
	WORD	*Stars_X;
	WORD	*Stars_Y;
	BYTE	*Stars_C;
	WORD	*Stars_Speed;

	RECT	MainRect;
	short	NumberOfStars;
	short	WarpFactor;
	short	MaxSpeed;

	short	Width;
	short	Height;
};



/* * * * Constructor & DeConstructor * * * */

HStars::HStars( )
{
	/* Initialize ZStars Main Data */
	this->Stars_X		=	NULL;
	this->Stars_Y		=	NULL;
	this->Stars_C		=	NULL;
	this->Stars_Speed	=	NULL;

	SetRect( &this->MainRect, 0, 0, 0, 0 );
	this->NumberOfStars	=	0;
	this->WarpFactor	=	0;
	this->MaxSpeed		=	0;

	this->Width			=	0;
	this->Height		=	0;
}

HStars::~HStars( )
{
	this->dispose( );
}


/* * * * Initializing Methods * * * */

void HStars::makeStars( RECT in_rect, short num_stars, short warp, short max_speed )
{
	/* If allready allocated, then dispose */
	this->dispose( );

	/* Allocate Space for StarsX */
	this->Stars_X = (WORD *) malloc( (long) num_stars * sizeof( WORD ) );
	if( this->Stars_X == NULL )
	{
		this->dispose( );
		return;
	}

	/* Allocate Space for StarsY */
	this->Stars_Y = (WORD *) malloc( (long) num_stars * sizeof( WORD ) );
	if( this->Stars_Y == NULL )
	{
		this->dispose( );
		return;
	}

	/* Allocate Space for StarsC */
	this->Stars_C = (BYTE *) malloc( (long) num_stars * sizeof( BYTE ) );
	if( this->Stars_C == NULL )
	{
		this->dispose( );
		return;
	}

	/* If diffrent speed, allocate speed array */
	this->Stars_Speed = (WORD *) malloc( (long) num_stars * sizeof( WORD ) );
	if( this->Stars_Speed == NULL )
	{
		this->dispose( );
		return;
	}

	/* Set other data member */
	this->MainRect			=	in_rect;
	this->NumberOfStars		=	num_stars;
	this->WarpFactor		=	warp;
	this->MaxSpeed			=	max_speed;
	
	this->Width  = (short) (this->MainRect.right - this->MainRect.left);
	this->Height = (short) (this->MainRect.bottom - this->MainRect.top);

	/* Set the stars at random pos X,Y,Z */
	for( int i=0; i<this->NumberOfStars; i++ )
	{
		Stars_X[ i ]		=	rnd( 0, this->Width * 10);
		Stars_Y[ i ]		=	rnd( 0, this->Height );
		Stars_C[ i ]		=	(byte) rnd( 100, 255 );
		Stars_Speed[ i ]	=	rnd( 1, 10 );
	}
}

void HStars::dispose( )
{
	/* If allocated Stars_X */
	if( this->Stars_X != NULL )
	{
		free( (void *) this->Stars_X );
		this->Stars_X = NULL;
	}

	/* If allocated Stars_Y */
	if( this->Stars_Y != NULL )
	{
		free( (void *) this->Stars_Y );
		this->Stars_Y = NULL;
	}

	/* If allocated Stars_C */
	if( this->Stars_C != NULL )
	{
		free( (void *) this->Stars_C );
		this->Stars_C = NULL;
	}

	/* If allocated Stars_Speed */
	if( this->Stars_Speed != NULL )
	{
		free( (void *) this->Stars_Speed );
		this->Stars_Speed = NULL;
	}
}

void HStars::drawStars( )
{
	int		i;

	game.lockPage( FrontPage );

	for( i=0; i<this->NumberOfStars; i++ )
	{
		game.putPixel8( Stars_X[ i ] / 10, Stars_Y[ i ], 0 );

		Stars_X[ i ] += this->Stars_Speed[ i ];

		if( Stars_X[ i ] > 639 * 10 )
			Stars_X[ i ] = 0;

		game.putPixel8( Stars_X[ i ] / 10, Stars_Y[ i ], (byte) Stars_C[ i ] );
	}

	game.unlockPage( FrontPage );
}

int HStars::rnd( int min, int max )
{
	return( (rand( ) % (max-min)) + min );
}
